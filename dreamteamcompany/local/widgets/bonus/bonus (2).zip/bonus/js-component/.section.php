<?
$sSectionName="js-component";
?>