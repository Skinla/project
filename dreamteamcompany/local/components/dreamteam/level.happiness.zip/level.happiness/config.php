<?php
$componentVendor = basename(dirname(__DIR__));
$componentCode = basename(__DIR__);
$componentName = $componentVendor.':'.$componentCode;
$dataFile = '/local/components/'.$componentVendor.'/'.$componentCode.'/data/levelHappiness.json';

return [
	'DATA_FILE' => $dataFile,
	'WIDGET_STYLE' => 'custom',
	'COMPANY_NAME' => 'Команда Мечты',
	'ENABLE_SYSTEM_NOTIFY' => 'Y',

	'COMPONENT_NAME' => $componentName,
	'SAVE_ACTION_NAME' => 'saveLevel',

	'MIN_LEVEL' => 1,
	'MAX_LEVEL' => 5,
	'STAR_SYMBOL' => '⭐',
	'STAR_SYMBOL_FILLED' => '★',
	'STAR_SYMBOL_EMPTY' => '☆',
	'LEVEL_LABEL_SUFFIX' => 'звезд',
	'BAR_COLORS' => [
		5 => '#4CAF50',
		4 => '#2196F3',
		3 => '#00bcd4',
		2 => '#ff9800',
		1 => '#f44336',
	],

	'FORM_TITLE' => 'Уровень счастья сотрудников',
	'FORM_QUESTION' => 'Какой твой уровень счастья сегодня!?',
	'ANONYMITY_TEXT' => 'Статистика полностью 🕵🏻‍♀️ анонимная!',
	'USER_LEVEL_PREFIX' => 'Ваш уровень счастья:',
	'BUTTON_TEXT' => 'Сохранить',
	'ENABLE_MANAGEMENT_BUTTON' => 'Y',
	'MANAGEMENT_BUTTON_TEXT' => 'Написать руководству',
	'MANAGEMENT_URL' => 'https://kmechty.ru/',
	'SELECT_PLACEHOLDER' => 'Мой уровень',

	'ENABLE_WIDGET_MOVE' => 'Y',
	'WIDGET_MOVE_TARGET_ID' => 'pulse_open_btn',
	'WIDGET_MOVE_POSITION' => 'afterend',
	'DOM_OBSERVER_TIMEOUT_MS' => 5000,
	'UI_NOTIFY_AUTOHIDE_MS' => 3000,

	'UI_MSG_SELECT_LEVEL' => 'Выбери уровень от 1 до 5 звезд.',
	'UI_MSG_SAVE_SUCCESS' => 'Оценка сохранена.',
	'UI_MSG_SAVE_ERROR' => 'Не удалось сохранить оценку.',
	'API_ERROR_EMPTY' => 'Заполнены не все поля.',
	'API_ERROR_INVALID' => 'Некорректный уровень счастья.',
	'API_ERROR_SAVE' => 'Не удалось сохранить оценку.',
	'API_ERROR_UNAUTHORIZED' => 'Пользователь не авторизован.',

	'NOTIFY_MESSAGE_SUCCESS' => 'Ваш уровень счастья изменен! 🚀',
	'NOTIFY_MESSAGE_EMPTY' => 'Ошибка! Заполнены не все поля! ❌',
	'NOTIFY_MESSAGE_RANGE' => "Ошибка!\nЗначение выходит за пределы диапазона! Маленький ты хакер 😼",
];
