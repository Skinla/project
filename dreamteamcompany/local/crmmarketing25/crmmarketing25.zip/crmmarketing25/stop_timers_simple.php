// Код для вставки в "Произвольный PHP-скрипт" в админке Bitrix
// ВАЖНО: Вставьте только код БЕЗ тегов <?php (они уже есть в интерфейсе)

// Определяем путь к скрипту
$scriptDir = '/local/handlers/crmmarketing25';
$pidFile = $_SERVER['DOCUMENT_ROOT'] . $scriptDir . '/deal_timer.pid';
$lockFile = $_SERVER['DOCUMENT_ROOT'] . $scriptDir . '/deal_timer.lock';

echo "<h2>Остановка всех процессов таймера</h2>";
echo "<pre>";

$killed = 0;

if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    // Windows - через wmic
    echo "Windows обнаружен\n\n";
    echo "Остановка процессов через wmic...\n";
    $output = [];
    @exec("wmic process where \"name='php.exe' and commandline like '%deal_webhook_handler.php%' and commandline like '%timer%'\" delete 2>NUL", $output, $result);
    if ($result === 0) {
        echo "✓ Процессы остановлены\n";
        $killed++;
    } else {
        echo "✗ Процессы не найдены или уже остановлены\n";
    }
} else {
    // Linux/Unix
    echo "Linux/Unix обнаружен\n\n";
    
    // Находим ВСЕ процессы deal_webhook_handler.php (включая таймеры)
    echo "Поиск всех процессов deal_webhook_handler.php...\n";
    
    // Метод 1: ps aux (полная командная строка)
    $psOutput = [];
    @exec("ps auxww | grep 'deal_webhook_handler.php' | grep -v grep", $psOutput);
    
    // Метод 2: pgrep (поиск по имени процесса)
    $pgrepOutput = [];
    @exec("pgrep -f 'deal_webhook_handler.php' 2>/dev/null", $pgrepOutput);
    
    $foundPids = [];
    
    // Обрабатываем ps
    foreach ($psOutput as $line) {
        if (preg_match('/\s+(\d+)\s+/', $line, $matches)) {
            $pid = (int)$matches[1];
            // Исключаем веб-запросы
            if (strpos($line, '?key=') === false && 
                strpos($line, 'action=') === false &&
                strpos($line, 'register') === false &&
                strpos($line, 'unregister') === false &&
                strpos($line, 'status') === false) {
                $foundPids[$pid] = $line;
                echo "Найден процесс PID: $pid\n";
                echo "  Команда: " . substr($line, 0, 200) . "\n";
            }
        }
    }
    
    // Обрабатываем pgrep (дополнительно)
    foreach ($pgrepOutput as $pidStr) {
        $pid = (int)trim($pidStr);
        if ($pid > 0 && !isset($foundPids[$pid])) {
            // Получаем полную командную строку
            $cmdOutput = [];
            @exec("ps -p $pid -o command= 2>/dev/null", $cmdOutput);
            $cmdLine = implode(' ', $cmdOutput);
            
            if (strpos($cmdLine, 'deal_webhook_handler.php') !== false &&
                strpos($cmdLine, '?key=') === false &&
                strpos($cmdLine, 'action=') === false) {
                $foundPids[$pid] = $cmdLine;
                echo "Найден процесс через pgrep PID: $pid\n";
                echo "  Команда: " . substr($cmdLine, 0, 200) . "\n";
            }
        }
    }
    
    if (empty($foundPids)) {
        echo "Процессы таймера не найдены через стандартные методы\n";
        echo "\nПопытка агрессивной остановки всех процессов deal_webhook_handler.php...\n";
        // Останавливаем ВСЕ процессы deal_webhook_handler.php (кроме текущего)
        $currentPid = getmypid();
        @exec("pkill -9 -f 'deal_webhook_handler.php' 2>&1", $pkillAllOutput, $pkillAllResult);
        echo "Команда pkill -9 выполнена (код: $pkillAllResult)\n";
        if ($pkillAllResult === 0 || $pkillAllResult === 1) {
            $killed = 999; // Помечаем как "остановлено все"
        }
    } else {
        echo "\nОстановка " . count($foundPids) . " процессов...\n";
        // Останавливаем через pkill
        @exec("pkill -f 'deal_webhook_handler.php.*timer' 2>&1", $pkillOutput, $pkillResult);
        
        // Дополнительно останавливаем каждый процесс через kill -9
        foreach ($foundPids as $pid => $cmdLine) {
            @exec("kill -9 $pid 2>&1", $killOutput, $killResult);
            if ($killResult === 0) {
                echo "✓ Процесс $pid остановлен\n";
                $killed++;
            } else {
                echo "✗ Процесс $pid уже остановлен или недоступен\n";
            }
        }
        
        // Проверяем, остались ли процессы
        sleep(1);
        $psOutput2 = [];
        @exec("ps aux | grep 'deal_webhook_handler.php' | grep timer | grep -v grep", $psOutput2);
        if (empty($psOutput2)) {
            echo "\n✓ Все процессы таймера успешно остановлены\n";
        } else {
            echo "\n⚠ ВНИМАНИЕ: Некоторые процессы все еще работают:\n";
            foreach ($psOutput2 as $line) {
                echo "  $line\n";
            }
        }
    }
}

// Удаляем файлы блокировки
echo "\nОчистка файлов блокировки...\n";
if (file_exists($pidFile)) {
    @unlink($pidFile);
    echo "✓ PID файл удален\n";
}
if (file_exists($lockFile)) {
    @unlink($lockFile);
    echo "✓ Lock файл удален\n";
}

echo "\n" . str_repeat("=", 50) . "\n";
echo "Остановлено процессов: $killed\n";
if ($killed > 0) {
    echo "✓ Все процессы таймера остановлены.\n";
} else {
    echo "ℹ Процессы таймера не найдены (возможно, уже остановлены).\n";
}
echo "\nТеперь используйте только Bitrix агент через deal_agent_manager.php\n";
echo "</pre>";

