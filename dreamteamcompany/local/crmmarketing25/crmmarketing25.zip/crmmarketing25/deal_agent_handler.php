<?php
/**
 * Bitrix агент для автоматической проверки новых сделок
 * Регистрация: /local/handlers/crmmarketing25/deal_agent_handler.php?register=1&key=...
 * Удаление: /local/handlers/crmmarketing25/deal_agent_handler.php?unregister=1&key=...
 */

// Инициализация Bitrix
(function (): void {
    $paths = [
        __DIR__ . '/bitrix_init.php',
        __DIR__ . '/../calltouch/calltouch_native/bitrix_init.php',
        __DIR__ . '/../calltouch/bitrix_init.php',
        dirname(__DIR__, 1) . '/calltouch/calltouch_native/bitrix_init.php',
    ];

    foreach ($paths as $path) {
        if (is_file($path)) {
            require_once $path;
            return;
        }
    }

    // Фолбэк на прямое подключение ядра
    if (!defined('NO_KEEP_STATISTIC')) {
        define('NO_KEEP_STATISTIC', true);
    }
    if (!defined('NO_AGENT_STATISTIC')) {
        define('NO_AGENT_STATISTIC', true);
    }
    if (!defined('NOT_CHECK_PERMISSIONS')) {
        define('NOT_CHECK_PERMISSIONS', true);
    }
    if (!defined('BX_WITH_ON_AFTER_EPILOG')) {
        define('BX_WITH_ON_AFTER_EPILOG', true);
    }

    if (empty($_SERVER['DOCUMENT_ROOT'])) {
        $_SERVER['DOCUMENT_ROOT'] = realpath(__DIR__ . '/../../..');
    }
    if (empty($_SERVER['HTTP_HOST'])) {
        $_SERVER['HTTP_HOST'] = $_SERVER['SERVER_NAME'] ?? 'localhost';
    }

    $prolog = $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';
    if (!is_file($prolog)) {
        throw new RuntimeException('Не удалось найти bitrix prolog для инициализации.');
    }
    require_once $prolog;
})();

use Bitrix\Main\Loader;

if (!Loader::includeModule('main')) {
    die('Модуль main не доступен');
}

// ВАЖНО: Проверяем флаг ДО любых других операций
// Если файл загружен из deal_agent_manager.php, не выполняем код вывода
$isManagerMode = isset($GLOBALS['DEAL_AGENT_MANAGER_MODE']) && $GLOBALS['DEAL_AGENT_MANAGER_MODE'];

if (!$isManagerMode) {
    // Ключ для доступа (только если файл вызывается напрямую)
    $accessKey = md5('deal_agent_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
    $expectedKey = md5('deal_agent_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
    $isAuthorized = isset($_GET['key']) && $_GET['key'] === $expectedKey;
}

// Имя агента
$agentName = 'DealExportAgent';
$agentFunction = __DIR__ . '/deal_webhook_handler.php';

// Функция агента (будет вызываться Bitrix автоматически)
function DealExportAgent()
{
    $handlerPath = __DIR__ . '/deal_webhook_handler.php';
    if (!file_exists($handlerPath)) {
        return 'DealExportAgent();';
    }

    try {
        // Захватываем вывод, чтобы не мешать работе агента
        ob_start();
        
        // Устанавливаем режим polling для корректной работы с файлом состояния
        $_REQUEST['mode'] = 'poll';
        $_REQUEST['action'] = 'poll';
        $_GET['mode'] = 'poll';
        $_GET['action'] = 'poll';
        
        // Загружаем класс без выполнения кода в конце файла
        // Используем условие, чтобы не выполнить код в конце deal_webhook_handler.php
        $GLOBALS['DEAL_AGENT_MODE'] = true;
        
        // Загружаем файл, но код в конце не выполнится из-за условия
        require_once $handlerPath;
        
        // Создаем экземпляр обработчика
        $handler = new DealToLeadWebhookHandler();
        
        // ВАЖНО: Убеждаемся, что не запустится таймер
        // Проверяем, что isTimerMode() вернет false
        if (method_exists($handler, 'isTimerMode')) {
            $reflection = new ReflectionClass($handler);
            $timerMethod = $reflection->getMethod('isTimerMode');
            $timerMethod->setAccessible(true);
            $isTimer = $timerMethod->invoke($handler);
            if ($isTimer) {
                error_log("DealExportAgent: ОШИБКА - обнаружен режим таймера! Пропускаем выполнение.");
                return 'DealExportAgent();';
            }
        }
        
        // Вызываем handlePolling через рефлексию (приватный метод)
        $reflection = new ReflectionClass($handler);
        $method = $reflection->getMethod('handlePolling');
        $method->setAccessible(true);
        
        // Логируем запуск агента
        $logMethod = $reflection->getMethod('log');
        $logMethod->setAccessible(true);
        $logMethod->invoke($handler, '[DealExportAgent] Запуск проверки новых сделок через Bitrix агент');
        
        // Вызываем handlePolling
        $method->invoke($handler);
        
        // Логируем завершение
        $logMethod->invoke($handler, '[DealExportAgent] Проверка завершена');
        
        // Очищаем буфер
        ob_end_clean();
        
        // Возвращаем имя функции для следующего запуска (каждую минуту)
        return 'DealExportAgent();';
    } catch (Throwable $e) {
        error_log("DealExportAgent error: " . $e->getMessage());
        // Продолжаем работу агента даже при ошибке
        return 'DealExportAgent();';
    }
}

// Регистрация агента (только если файл вызывается напрямую)
if (!$isManagerMode && isset($_GET['register']) && isset($isAuthorized) && $isAuthorized) {
    $agent = new \CAgent();
    
    // Удаляем старый агент, если есть
    $agent->Delete([
        'NAME' => 'DealExportAgent();',
    ]);
    
    // Регистрируем новый агент (каждые 10 минут)
    // Устанавливаем следующий запуск на текущее время, чтобы агент запустился сразу
    $nextExec = date('d.m.Y H:i:s');
    $agentId = $agent->AddAgent(
        'DealExportAgent();',
        '',
        'N', // не критичный
        600, // интервал в секундах (10 минут)
        '', // дата начала
        'Y', // активен
        $nextExec, // дата следующего запуска (сразу)
        'Y' // сортировка
    );
    
    if ($agentId) {
        echo json_encode([
            'success' => true,
            'message' => "Агент успешно зарегистрирован (ID: {$agentId}). Будет запускаться каждые 10 минут.",
            'agent_id' => $agentId
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Ошибка регистрации агента: ' . $agent->LAST_ERROR
        ]);
    }
    exit;
}

// Удаление агента (только если файл вызывается напрямую)
if (!$isManagerMode && isset($_GET['unregister']) && isset($isAuthorized) && $isAuthorized) {
    $agent = new \CAgent();
    $agentName = 'DealExportAgent();';
    
    // Сначала находим всех агентов с таким именем
    $dbAgents = $agent->GetList(
        ['ID' => 'DESC'],
        ['NAME' => $agentName]
    );
    
    $deleted = false;
    $deletedCount = 0;
    $deactivatedCount = 0;
    $errors = [];
    
    while ($arAgent = $dbAgents->Fetch()) {
        $agentId = $arAgent['ID'];
        
        // Пробуем удалить по ID
        if ($agent->Delete($agentId)) {
            $deletedCount++;
            $deleted = true;
        } else {
            // Если удаление не сработало, деактивируем агента
            $updateResult = $agent->Update($agentId, [
                'ACTIVE' => 'N'
            ]);
            if ($updateResult) {
                $deactivatedCount++;
                $deleted = true;
            } else {
                $errors[] = "Не удалось удалить/деактивировать агент ID: {$agentId}";
            }
        }
    }
    
    if ($deleted) {
        $msg = [];
        if ($deletedCount > 0) {
            $msg[] = "удалено: {$deletedCount}";
        }
        if ($deactivatedCount > 0) {
            $msg[] = "деактивировано: {$deactivatedCount}";
        }
        echo json_encode([
            'success' => true,
            'message' => "Агент успешно обработан (" . implode(', ', $msg) . ")"
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Агент не найден или уже удален. ' . implode(' ', $errors)
        ]);
    }
    exit;
}

// Проверка статуса агента (только если файл вызывается напрямую)
if (!$isManagerMode && isset($_GET['status']) && isset($isAuthorized) && $isAuthorized) {
    $agent = new \CAgent();
    $dbAgents = $agent->GetList(
        ['ID' => 'DESC'],
        ['NAME' => 'DealExportAgent();']
    );
    
    $agents = [];
    while ($arAgent = $dbAgents->Fetch()) {
        $agents[] = [
            'id' => $arAgent['ID'],
            'active' => $arAgent['ACTIVE'] === 'Y',
            'last_exec' => $arAgent['LAST_EXEC'],
            'next_exec' => $arAgent['NEXT_EXEC'],
            'interval' => $arAgent['AGENT_INTERVAL'],
        ];
    }
    
    echo json_encode([
        'success' => true,
        'agents' => $agents,
        'count' => count($agents)
    ]);
    exit;
}

// Если файл загружен из deal_agent_manager.php, завершаем выполнение здесь
if ($isManagerMode) {
    // Функция DealExportAgent уже определена выше, просто завершаем
    return;
}

// Если это вызов агента (не через GET параметры)
if (PHP_SAPI === 'cli' || (empty($_GET) && empty($_POST))) {
    DealExportAgent();
    exit;
}

// Проверяем, вызывается ли файл напрямую или через require/include
$isDirectCall = false;
if (isset($_SERVER['SCRIPT_NAME'])) {
    $isDirectCall = (basename(__FILE__) === basename($_SERVER['SCRIPT_NAME']));
}
if (!$isDirectCall && isset($_SERVER['SCRIPT_FILENAME'])) {
    $isDirectCall = (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME']));
}

// Выводим JSON только если файл вызывается напрямую
if ($isDirectCall && !$isManagerMode) {
    // Если не авторизован, показываем информацию
    if (!isset($isAuthorized) || !$isAuthorized) {
        header('Content-Type: application/json');
        echo json_encode([
            'error' => 'Доступ запрещен',
            'key' => $accessKey,
            'usage' => [
                'register' => '?register=1&key=' . $accessKey,
                'unregister' => '?unregister=1&key=' . $accessKey,
                'status' => '?status=1&key=' . $accessKey,
            ]
        ]);
        exit;
    }

    // Показываем информацию об использовании
    header('Content-Type: application/json');
    echo json_encode([
        'message' => 'Используйте параметры: register, unregister или status',
        'key' => $accessKey
    ]);
    exit;
}

