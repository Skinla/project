<?php
/**
 * Скрипт для остановки всех процессов таймера deal_webhook_handler.php
 * Запуск: php kill_timer_processes.php
 */

// Инициализация Bitrix (минимальная)
if (empty($_SERVER['DOCUMENT_ROOT'])) {
    $_SERVER['DOCUMENT_ROOT'] = realpath(__DIR__ . '/../../..');
}

$scriptPath = __DIR__ . '/deal_webhook_handler.php';
$pidFile = __DIR__ . '/deal_timer.pid';

echo "Поиск и остановка процессов таймера...\n\n";

if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    // Windows
    echo "Windows обнаружен\n";
    
    // Ищем процессы через tasklist
    $output = [];
    @exec('tasklist /FI "IMAGENAME eq php.exe" /FO CSV', $output);
    
    $killed = 0;
    foreach ($output as $line) {
        if (strpos($line, 'php.exe') !== false) {
            // Пытаемся получить PID
            $parts = str_getcsv($line);
            if (isset($parts[1]) && is_numeric($parts[1])) {
                $pid = (int)$parts[1];
                
                // Проверяем командную строку процесса
                $cmdOutput = [];
                @exec("wmic process where processid=$pid get commandline 2>NUL", $cmdOutput);
                $cmdLine = implode(' ', $cmdOutput);
                
                if (strpos($cmdLine, 'deal_webhook_handler.php') !== false && 
                    (strpos($cmdLine, 'timer') !== false || strpos($cmdLine, 'mode=timer') !== false)) {
                    echo "Найден процесс таймера PID: $pid\n";
                    echo "Команда: $cmdLine\n";
                    
                    // Останавливаем процесс
                    @exec("taskkill /F /PID $pid 2>NUL", $killOutput, $killResult);
                    if ($killResult === 0) {
                        echo "✓ Процесс $pid остановлен\n";
                        $killed++;
                    } else {
                        echo "✗ Не удалось остановить процесс $pid\n";
                    }
                }
            }
        }
    }
    
    // Удаляем PID файл
    if (file_exists($pidFile)) {
        @unlink($pidFile);
        echo "✓ PID файл удален\n";
    }
    
    echo "\nОстановлено процессов: $killed\n";
    
} else {
    // Linux/Unix
    echo "Linux/Unix обнаружен\n";
    
    // Ищем процессы через ps
    $output = [];
    @exec("ps aux | grep 'deal_webhook_handler.php' | grep -v grep", $output);
    
    $killed = 0;
    foreach ($output as $line) {
        if (preg_match('/\s+(\d+)\s+/', $line, $matches)) {
            $pid = (int)$matches[1];
            
            // Проверяем, что это процесс таймера
            if (strpos($line, 'timer') !== false || strpos($line, 'mode=timer') !== false) {
                echo "Найден процесс таймера PID: $pid\n";
                echo "Команда: $line\n";
                
                // Останавливаем процесс
                @exec("kill -9 $pid 2>&1", $killOutput, $killResult);
                if ($killResult === 0) {
                    echo "✓ Процесс $pid остановлен\n";
                    $killed++;
                } else {
                    echo "✗ Не удалось остановить процесс $pid\n";
                }
            }
        }
    }
    
    // Удаляем PID файл
    if (file_exists($pidFile)) {
        @unlink($pidFile);
        echo "✓ PID файл удален\n";
    }
    
    echo "\nОстановлено процессов: $killed\n";
}

echo "\nГотово! Все процессы таймера должны быть остановлены.\n";
echo "Теперь используйте только Bitrix агент через deal_agent_manager.php\n";

