<?php
/**
 * Веб-интерфейс для управления таймером выгрузки сделок
 * Доступ: /local/handlers/crmmarketing25/deal_timer_manager.php
 */

// Устанавливаем таймаут для избежания зависаний
set_time_limit(30);
ignore_user_abort(false);

// Запускаем сессию для авторизации
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Загружаем конфигурацию
$configPath = __DIR__ . '/calltouch_config.php';
$config = is_file($configPath) ? include $configPath : [];
if (!is_array($config)) { $config = []; }

// Генерируем ключ для доступа (аналогично queue_manager.php)
$accessKey = md5('deal_timer_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));

// Файл для хранения PID процесса
$pidFile = __DIR__ . '/deal_timer.pid';
$logFile = __DIR__ . '/deal_timer.log';
$scriptPath = __DIR__ . '/deal_webhook_handler.php';

// Простая проверка авторизации
$isAuthorized = false;
if (isset($_GET['key'])) {
    $expectedKey = md5('deal_timer_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
    $isAuthorized = ($_GET['key'] === $expectedKey);
} elseif (isset($_SESSION['deal_timer_authorized'])) {
    $isAuthorized = true;
}

// Функция для очистки кэша статуса
function clearStatusCache($pidFile) {
    $cacheFile = __DIR__ . '/.status_cache_' . md5($pidFile);
    @unlink($cacheFile);
}

// Функции управления процессом
function isProcessRunning($pidFile, $scriptPath = '', $useWmic = false) {
    if (!file_exists($pidFile)) {
        return false;
    }
    
    // Проверяем время модификации файла - если файл обновлялся недавно (менее 10 минут назад), процесс скорее всего запущен
    $fileMTime = filemtime($pidFile);
    $timeSinceUpdate = time() - $fileMTime;
    
    // Если файл обновлялся более 10 минут назад, процесс точно не запущен
    if ($timeSinceUpdate > 600) {
        return false;
    }
    
    $content = trim(file_get_contents($pidFile));
    
    // Проверяем, существует ли процесс
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // На Windows: если файл обновлялся недавно, считаем процесс запущенным
        // Проверка через wmic медленная, поэтому используем её только при необходимости (например, при остановке)
        if ($useWmic) {
            $scriptName = basename($scriptPath ?: 'deal_webhook_handler.php');
            
            // Пытаемся найти процесс через wmic (с таймаутом)
            $output = [];
            @exec('wmic process where "name=\'php.exe\'" get commandline,processid 2>NUL', $output);
            
            if (!empty($output)) {
                $commandLine = '';
                $processId = '';
                
                foreach ($output as $line) {
                    $line = trim($line);
                    if (empty($line)) {
                        continue;
                    }
                    
                    if (stripos($line, 'CommandLine') !== false && stripos($line, 'ProcessId') !== false) {
                        continue;
                    }
                    
                    if (preg_match('/^(.+?)\s+(\d+)\s*$/', $line, $matches)) {
                        $commandLine = $matches[1];
                        $processId = $matches[2];
                    } elseif (preg_match('/^(.+)$/', $line, $matches) && empty($processId)) {
                        $commandLine .= ' ' . $matches[1];
                    } elseif (preg_match('/^(\d+)\s*$/', $line, $matches)) {
                        $processId = $matches[1];
                    }
                    
                    if (!empty($commandLine) && !empty($processId)) {
                        if (stripos($commandLine, $scriptName) !== false && stripos($commandLine, 'timer') !== false) {
                            return true;
                        }
                        $commandLine = '';
                        $processId = '';
                    }
                }
            }
        }
        
        // Если wmic не используется или не сработал, проверяем по времени модификации файла
        // Если файл обновлялся менее 10 минут назад, считаем процесс запущенным
        return $timeSinceUpdate < 600;
    } else {
        $pid = (int)$content;
        if ($pid <= 0) {
            return false;
        }
        $result = @exec("ps -p $pid -o pid= 2>/dev/null");
        return !empty($result);
    }
}

function getProcessInfo($pidFile, $useWmic = false) {
    if (!file_exists($pidFile)) {
        return null;
    }
    $content = trim(file_get_contents($pidFile));
    
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // На Windows извлекаем информацию из PID файла без медленного wmic
        if (strpos($content, 'WIN:') === 0) {
            $parts = explode(':', $content, 3);
            $timestamp = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : 0;
            $scriptName = $parts[2] ?? '';
            $startTime = $timestamp > 0 ? date('Y-m-d H:i:s', $timestamp) : '';
            return [
                'pid' => 'WIN',
                'start_time' => $startTime,
                'script' => $scriptName
            ];
        } else {
            $pid = (int)$content;
            if ($pid > 0) {
                // Только если явно запрошено, используем медленный wmic
                if ($useWmic) {
                    $output = [];
                    @exec("wmic process where processid=$pid get commandline,creationdate 2>NUL", $output);
                    return ['pid' => $pid, 'info' => implode("\n", $output)];
                } else {
                    // Быстрая версия без wmic
                    return ['pid' => $pid, 'start_time' => ''];
                }
            }
        }
        return null;
    } else {
        $pid = (int)$content;
        if ($pid <= 0) {
            return null;
        }
        $cmdline = @exec("ps -p $pid -o command= 2>/dev/null");
        $startTime = @exec("ps -p $pid -o lstart= 2>/dev/null");
        return ['pid' => $pid, 'cmdline' => $cmdline, 'start_time' => $startTime];
    }
}

function stopProcess($pidFile, $scriptPath = '') {
    if (!file_exists($pidFile)) {
        return false;
    }
    
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // На Windows останавливаем процессы PHP, которые запускают наш скрипт
        $scriptName = basename($scriptPath ?: 'deal_webhook_handler.php');
        
        // Пытаемся остановить через wmic одним запросом (самый быстрый способ)
        @exec("wmic process where \"name='php.exe' and commandline like '%$scriptName%' and commandline like '%timer%'\" delete 2>NUL");
        
        // Удаляем PID файл (процесс может быть уже остановлен или остановится)
        @unlink($pidFile);
        clearStatusCache($pidFile);
        return true;
    } else {
        $content = trim(file_get_contents($pidFile));
        $pid = (int)$content;
        if ($pid > 0) {
            @exec("kill $pid 2>/dev/null");
        }
        @unlink($pidFile);
        clearStatusCache($pidFile);
        return true;
    }
}

function startProcess($scriptPath, $interval, $pidFile, $logFile) {
    $phpPath = 'php';
    
    // Определяем путь к PHP
    if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
        $whichOutput = [];
        @exec('which php', $whichOutput);
        if (!empty($whichOutput[0]) && file_exists($whichOutput[0])) {
            $phpPath = trim($whichOutput[0]);
        }
    }
    
    $interval = max(10, min(600, (int)$interval)); // 10-600 секунд
    
    // Запускаем через nohup в фоне
    // ВАЖНО: Процесс запускается как независимый и будет работать даже после закрытия браузера
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows - создаем VBScript для запуска в фоне без блокировки
        // WshShell.Run с параметром 0 = скрытое окно, False = не ждать завершения (асинхронный запуск)
        $vbsFile = __DIR__ . '/start_timer_' . time() . '.vbs';
        $scriptDir = str_replace('\\', '\\\\', dirname($scriptPath));
        $scriptName = basename($scriptPath);
        $logFileEscaped = str_replace('\\', '\\\\', $logFile);
        
        $vbsContent = sprintf(
            'Set WshShell = CreateObject("WScript.Shell")' . PHP_EOL .
            'WshShell.CurrentDirectory = "%s"' . PHP_EOL .
            'WshShell.Run "php %s timer interval=%d >> %s 2>&1", 0, False' . PHP_EOL .
            'Set fso = CreateObject("Scripting.FileSystemObject")' . PHP_EOL .
            'On Error Resume Next' . PHP_EOL .
            'WScript.Sleep 1000' . PHP_EOL .
            'fso.DeleteFile WScript.ScriptFullName',
            $scriptDir,
            $scriptName,
            $interval,
            $logFileEscaped
        );
        file_put_contents($vbsFile, $vbsContent);
        
        // Запускаем VBScript через start в фоне (неблокирующий)
        // Процесс PHP запускается независимо от веб-сервера и браузера
        $vbsFileEscaped = str_replace('/', '\\', $vbsFile);
        @exec('start /MIN wscript.exe //B "' . $vbsFileEscaped . '" > NUL 2>&1');
        
        // На Windows записываем время запуска и имя процесса для проверки
        file_put_contents($pidFile, 'WIN:' . time() . ':' . basename($scriptPath));
        clearStatusCache($pidFile);
        return true;
    } else {
        // Linux/Unix
        // nohup запускает процесс независимо от родительского процесса
        // & в конце запускает процесс в фоне
        // Процесс будет работать даже после закрытия браузера
        $cmd = sprintf(
            'cd %s && nohup %s %s timer interval=%d >> %s 2>&1 & echo $!',
            escapeshellarg(dirname($scriptPath)),
            escapeshellarg($phpPath),
            escapeshellarg(basename($scriptPath)),
            $interval,
            escapeshellarg($logFile)
        );
        $pid = trim(@exec($cmd));
        if (!empty($pid) && is_numeric($pid)) {
            file_put_contents($pidFile, $pid);
            clearStatusCache($pidFile);
            return true;
        }
    }
    
    return false;
}

// Обработка действий
$message = '';
$messageType = '';
$isAjax = isset($_POST['ajax']) && $_POST['ajax'] === '1';
$actionResult = null;

if ($isAuthorized) {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'start' && isset($_POST['interval'])) {
            $interval = (int)$_POST['interval'];
            if ($interval >= 10 && $interval <= 600) {
                if (isProcessRunning($pidFile, $scriptPath)) {
                    $actionResult = ['success' => false, 'message' => 'Процесс уже запущен', 'messageType' => 'error'];
                } else {
                    // Для AJAX не запускаем процесс здесь, запустим после отправки ответа
                    if ($isAjax) {
                        $actionResult = ['success' => true, 'message' => "Таймер запускается с интервалом {$interval} секунд", 'messageType' => 'success'];
                    } else {
                        if (startProcess($scriptPath, $interval, $pidFile, $logFile)) {
                            $actionResult = ['success' => true, 'message' => "Таймер запущен с интервалом {$interval} секунд", 'messageType' => 'success'];
                        } else {
                            $actionResult = ['success' => false, 'message' => 'Ошибка запуска процесса', 'messageType' => 'error'];
                        }
                    }
                }
            } else {
                $actionResult = ['success' => false, 'message' => 'Интервал должен быть от 10 до 600 секунд', 'messageType' => 'error'];
            }
            $_SESSION['deal_timer_authorized'] = true;
        } elseif ($_POST['action'] === 'stop') {
            if (isProcessRunning($pidFile, $scriptPath)) {
                // Для AJAX не останавливаем процесс здесь, сделаем после отправки ответа
                if ($isAjax) {
                    $actionResult = ['success' => true, 'message' => 'Процесс останавливается...', 'messageType' => 'success'];
                } else {
                    if (stopProcess($pidFile, $scriptPath)) {
                        $actionResult = ['success' => true, 'message' => 'Процесс остановлен', 'messageType' => 'success'];
                    } else {
                        $actionResult = ['success' => false, 'message' => 'Ошибка остановки процесса', 'messageType' => 'error'];
                    }
                }
            } else {
                $actionResult = ['success' => false, 'message' => 'Процесс не запущен', 'messageType' => 'error'];
            }
            $_SESSION['deal_timer_authorized'] = true;
        } elseif ($_POST['action'] === 'restart' && isset($_POST['interval'])) {
            $interval = (int)$_POST['interval'];
            if ($interval >= 10 && $interval <= 600) {
                // Для AJAX не останавливаем и не запускаем процесс здесь, сделаем после отправки ответа
                if ($isAjax) {
                    $actionResult = ['success' => true, 'message' => "Процесс перезапускается с интервалом {$interval} секунд", 'messageType' => 'success'];
                } else {
                    if (isProcessRunning($pidFile, $scriptPath)) {
                        stopProcess($pidFile, $scriptPath);
                    }
                    // Небольшая задержка только для остановки процесса (минимальная)
                    usleep(100000); // 0.1 секунды
                    if (startProcess($scriptPath, $interval, $pidFile, $logFile)) {
                        $actionResult = ['success' => true, 'message' => "Процесс перезапущен с интервалом {$interval} секунд", 'messageType' => 'success'];
                    } else {
                        $actionResult = ['success' => false, 'message' => 'Ошибка перезапуска процесса', 'messageType' => 'error'];
                    }
                }
            } else {
                $actionResult = ['success' => false, 'message' => 'Интервал должен быть от 10 до 600 секунд', 'messageType' => 'error'];
            }
            $_SESSION['deal_timer_authorized'] = true;
        }
        
        // Для AJAX-запросов возвращаем JSON сразу, а операции с процессом делаем после отправки ответа
        if ($isAjax && $actionResult !== null) {
            $action = $_POST['action'] ?? '';
            
            // Регистрируем функцию для выполнения после отправки ответа
            if ($action === 'stop' && $actionResult['success']) {
                // Останавливаем процесс после отправки ответа
                register_shutdown_function(function() use ($pidFile, $scriptPath) {
                    stopProcess($pidFile, $scriptPath);
                });
            } elseif (($action === 'start' || $action === 'restart') && $actionResult['success']) {
                // Запускаем процесс в фоне после отправки ответа
                $interval = (int)($_POST['interval'] ?? 300);
                
                register_shutdown_function(function() use ($action, $interval, $scriptPath, $pidFile, $logFile) {
                    if ($interval >= 10 && $interval <= 600) {
                        // Для restart сначала останавливаем процесс
                        if ($action === 'restart' && isProcessRunning($pidFile, $scriptPath)) {
                            stopProcess($pidFile, $scriptPath);
                            usleep(200000); // 0.2 секунды для остановки
                        }
                        
                        startProcess($scriptPath, $interval, $pidFile, $logFile);
                    }
                });
            }
            
            // Отправляем ответ клиенту
            header('Content-Type: application/json');
            if (ob_get_level()) {
                ob_end_clean();
            }
            echo json_encode($actionResult);
            
            // Завершаем ответ немедленно
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            } else {
                if (ob_get_level()) {
                    ob_end_flush();
                }
                flush();
            }
            
            exit;
        }
        
        // Для обычных запросов сохраняем в сессию и делаем редирект
        if ($actionResult !== null) {
            // Очищаем кэш статуса, чтобы при редиректе получить актуальные данные
            clearStatusCache($pidFile);
            
            $_SESSION['deal_timer_message'] = $actionResult['message'];
            $_SESSION['deal_timer_message_type'] = $actionResult['messageType'];
            if (ob_get_level()) {
                ob_end_clean();
            }
            $key = $_GET['key'] ?? '';
            $url = $_SERVER['PHP_SELF'] . ($key ? '?key=' . urlencode($key) : '');
            header('Location: ' . $url);
            
            // Завершаем ответ сразу, если доступно
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            } else {
                flush();
            }
            exit;
        }
        
    }
    
    // Получаем сообщения из сессии
    if (isset($_SESSION['deal_timer_message'])) {
        $message = $_SESSION['deal_timer_message'];
        $messageType = $_SESSION['deal_timer_message_type'] ?? 'success';
        unset($_SESSION['deal_timer_message'], $_SESSION['deal_timer_message_type']);
    }
}

// Проверяем, это запрос статуса или лога через AJAX?
$isStatusCheck = isset($_GET['status_check']) && $_GET['status_check'] === '1';
$isLogRequest = isset($_GET['get_log']) && $_GET['get_log'] === '1';

// Если это запрос статуса через AJAX, возвращаем JSON
if ($isStatusCheck) {
    // Проверяем авторизацию для запроса статуса
    $statusKey = $_GET['key'] ?? '';
    $expectedKey = md5('deal_timer_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
    $statusAuthorized = ($statusKey === $expectedKey) || (isset($_SESSION['deal_timer_authorized']) && $_SESSION['deal_timer_authorized']);
    
    if ($statusAuthorized) {
        // Проверяем статус без кэша для актуальных данных
        $isRunningStatus = isProcessRunning($pidFile, $scriptPath);
        $processInfoStatus = $isRunningStatus ? getProcessInfo($pidFile) : null;
        
        header('Content-Type: application/json');
        echo json_encode([
            'isRunning' => $isRunningStatus,
            'processInfo' => $processInfoStatus,
            'statusText' => $isRunningStatus ? '🟢 Запущен' : '🔴 Остановлен',
            'statusClass' => $isRunningStatus ? 'running' : 'stopped'
        ]);
        exit;
    } else {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Доступ запрещен']);
        exit;
    }
}

// Если это запрос лога через AJAX, возвращаем только лог
if ($isLogRequest) {
    // Проверяем авторизацию для запроса лога
    $logKey = $_GET['key'] ?? '';
    $expectedKey = md5('deal_timer_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
    $logAuthorized = ($logKey === $expectedKey) || (isset($_SESSION['deal_timer_authorized']) && $_SESSION['deal_timer_authorized']);
    
    if ($logAuthorized) {
        header('Content-Type: application/json');
        $logData = '';
        if (file_exists($logFile)) {
            $fileSize = @filesize($logFile);
            if ($fileSize !== false && $fileSize > 0 && $fileSize < 10 * 1024 * 1024) {
                $maxBytes = 50 * 1024; // 50KB
                $handle = @fopen($logFile, 'r');
                if ($handle) {
                    if ($fileSize > $maxBytes) {
                        fseek($handle, -$maxBytes, SEEK_END);
                        fgets($handle); // Пропускаем первую неполную строку
                    }
                    $content = '';
                    while (!feof($handle) && strlen($content) < $maxBytes) {
                        $content .= fread($handle, 8192);
                    }
                    fclose($handle);
                    $lines = explode("\n", $content);
                    $logData = implode("\n", array_slice($lines, -50));
                }
            }
        }
        echo json_encode(['log' => $logData ?: 'Лог пуст']);
        exit;
    } else {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Доступ запрещен']);
        exit;
    }
}

// Проверяем статус процесса (с кэшированием на 2 секунды для быстрой загрузки)
$cacheFile = __DIR__ . '/.status_cache_' . md5($pidFile);
$cacheTime = 2; // секунды
$isRunning = false;
$processInfo = null;

// Проверяем статус процесса (с кэшированием на 2 секунды для быстрой загрузки)
// НЕ используем кэш для запросов статуса через AJAX, чтобы получить актуальные данные
$useCache = !$isStatusCheck;

if ($useCache && file_exists($cacheFile)) {
    $cacheData = @json_decode(file_get_contents($cacheFile), true);
    if (is_array($cacheData) && isset($cacheData['time']) && is_numeric($cacheData['time']) && (time() - $cacheData['time']) < $cacheTime) {
        // Используем кэшированные данные
        $isRunning = isset($cacheData['isRunning']) ? (bool)$cacheData['isRunning'] : false;
        $processInfo = isset($cacheData['processInfo']) && is_array($cacheData['processInfo']) ? $cacheData['processInfo'] : null;
    } else {
        // Кэш устарел или некорректен, проверяем заново
        $isRunning = isProcessRunning($pidFile, $scriptPath);
        $processInfo = $isRunning ? getProcessInfo($pidFile) : null;
        // Сохраняем в кэш
        @file_put_contents($cacheFile, json_encode([
            'time' => time(),
            'isRunning' => $isRunning,
            'processInfo' => $processInfo
        ]));
    }
} else {
    // Кэша нет или не используем кэш, проверяем
    $isRunning = isProcessRunning($pidFile, $scriptPath);
    $processInfo = $isRunning ? getProcessInfo($pidFile) : null;
    // Сохраняем в кэш только если не запрос статуса
    if ($useCache) {
        @file_put_contents($cacheFile, json_encode([
            'time' => time(),
            'isRunning' => $isRunning,
            'processInfo' => $processInfo
        ]));
    }
}

// Читаем последние строки лога (оптимизированно, без загрузки всего файла)
// Для AJAX-запросов статуса не читаем лог для ускорения
// Для обычных запросов тоже не читаем сразу - загрузим через AJAX после загрузки страницы
$logContent = '';
$logFileSize = 0;
if (!$isStatusCheck) {
    // Только проверяем размер файла, не читаем содержимое
    if (file_exists($logFile)) {
        $logFileSize = @filesize($logFile);
        // Если файл маленький (меньше 100KB), читаем сразу
        if ($logFileSize !== false && $logFileSize > 0 && $logFileSize < 100 * 1024) {
            $handle = @fopen($logFile, 'r');
            if ($handle) {
                $content = '';
                while (!feof($handle) && strlen($content) < 50 * 1024) {
                    $content .= fread($handle, 8192);
                }
                fclose($handle);
                
                // Берем последние 50 строк
                $lines = explode("\n", $content);
                $logContent = implode("\n", array_slice($lines, -50));
            }
        }
        // Для больших файлов лог будет загружен через AJAX после загрузки страницы
    }
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление таймером выгрузки сделок</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            color: #333;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 30px;
        }
        h1 {
            margin-bottom: 30px;
            color: #2c3e50;
        }
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 4px solid #4caf50;
        }
        .message.error {
            background: #ffebee;
            color: #c62828;
            border-left-color: #f44336;
        }
        .status-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .status-card.running {
            background: linear-gradient(135deg, #4caf50 0%, #45a049 100%);
        }
        .status-card.stopped {
            background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%);
        }
        .status-card h2 {
            font-size: 1.5em;
            margin-bottom: 10px;
        }
        .status-info {
            font-size: 0.9em;
            opacity: 0.9;
        }
        .control-panel {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 4px;
            margin-bottom: 30px;
        }
        .control-panel h3 {
            margin-bottom: 15px;
            color: #34495e;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #555;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .form-group input[type="number"] {
            max-width: 200px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #2196F3;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
            margin-bottom: 10px;
        }
        .btn:hover {
            background: #1976D2;
        }
        .btn-success {
            background: #4caf50;
        }
        .btn-success:hover {
            background: #45a049;
        }
        .btn-danger {
            background: #f44336;
        }
        .btn-danger:hover {
            background: #d32f2f;
        }
        .btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        .log-section {
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 20px;
            border-radius: 4px;
            max-height: 400px;
            overflow-y: auto;
        }
        .log-section pre {
            margin: 0;
            font-family: 'Courier New', Courier, monospace;
            font-size: 12px;
            line-height: 1.5;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .access-info {
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .quick-intervals {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            flex-wrap: wrap;
        }
        .quick-interval-btn {
            padding: 5px 15px;
            background: #e0e0e0;
            border: 1px solid #ccc;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }
        .quick-interval-btn:hover {
            background: #d0d0d0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>⏱️ Управление таймером выгрузки сделок</h1>
        
        <?php if (!$isAuthorized): ?>
            <div class="access-info">
                <p><strong>🔒 Доступ запрещен</strong></p>
                <p>Для доступа к интерфейсу требуется код доступа.</p>
                <p style="margin-top: 10px; font-size: 0.9em; color: #666;">
                    Код доступа: <code><?php echo htmlspecialchars($accessKey); ?></code>
                </p>
                <p style="margin-top: 10px; font-size: 0.9em; color: #666;">
                    Добавьте <code>?key=<?php echo htmlspecialchars($accessKey); ?></code> к URL
                </p>
            </div>
        <?php endif; ?>
        
        <?php if ($message): ?>
            <div class="message <?php echo $messageType === 'error' ? 'error' : ''; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($isAuthorized): ?>
            <div class="status-card <?php echo $isRunning ? 'running' : 'stopped'; ?>">
                <h2><?php echo $isRunning ? '🟢 Запущен' : '🔴 Остановлен'; ?></h2>
                <div class="status-info">
                    <?php if ($isRunning): ?>
                        <?php if ($processInfo): ?>
                            <p><strong>PID:</strong> <?php echo htmlspecialchars($processInfo['pid'] ?? 'N/A'); ?></p>
                            <?php if (isset($processInfo['start_time']) && !empty($processInfo['start_time'])): ?>
                                <p><strong>Запущен:</strong> <?php echo htmlspecialchars($processInfo['start_time']); ?></p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p>Процесс запущен</p>
                        <?php endif; ?>
                        <p style="margin-top: 10px; font-size: 0.9em; color: #666; font-style: italic;">
                            ℹ️ Процесс работает в фоне независимо от браузера. Можно закрыть эту страницу.
                        </p>
                    <?php else: ?>
                        <p>Процесс не запущен</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="control-panel">
                <h3>Управление</h3>
                <form id="controlForm" onsubmit="return handleFormSubmit(event);">
                    <input type="hidden" name="key" value="<?php echo htmlspecialchars($accessKey); ?>">
                    
                    <div class="form-group">
                        <label for="interval">Интервал проверки (секунды, от 10 до 600):</label>
                        <input type="number" id="interval" name="interval" value="300" min="10" max="600" required>
                        <div class="quick-intervals">
                            <span>Быстрый выбор:</span>
                            <button type="button" class="quick-interval-btn" onclick="document.getElementById('interval').value = '60'">1 мин</button>
                            <button type="button" class="quick-interval-btn" onclick="document.getElementById('interval').value = '120'">2 мин</button>
                            <button type="button" class="quick-interval-btn" onclick="document.getElementById('interval').value = '300'">5 мин</button>
                            <button type="button" class="quick-interval-btn" onclick="document.getElementById('interval').value = '600'">10 мин</button>
                        </div>
                    </div>
                    
                    <div id="actionButtons">
                        <?php if ($isRunning): ?>
                            <button type="button" onclick="performAction('restart')" class="btn">🔄 Перезапустить</button>
                            <button type="button" onclick="performAction('stop')" class="btn btn-danger">⏹️ Остановить</button>
                        <?php else: ?>
                            <button type="button" onclick="performAction('start')" class="btn btn-success">▶️ Запустить</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <div class="log-section">
                <h3 style="color: #f8f8f2; margin-bottom: 15px;">Последние записи лога:</h3>
                <pre id="logContent"><?php echo htmlspecialchars($logContent ?: 'Загрузка лога...'); ?></pre>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        const accessKey = '<?php echo htmlspecialchars($accessKey, ENT_QUOTES); ?>';
        const isRunning = <?php echo $isRunning ? 'true' : 'false'; ?>;
        let statusCheckInterval = null;
        
        function handleFormSubmit(event) {
            event.preventDefault();
            return false;
        }
        
        function performAction(action) {
            const interval = document.getElementById('interval').value;
            
            if (!interval || interval < 10 || interval > 600) {
                alert('Интервал должен быть от 10 до 600 секунд');
                return;
            }
            
            if (action === 'stop' && !confirm('Остановить таймер?')) {
                return;
            }
            
            // Показываем индикатор загрузки
            const buttons = document.getElementById('actionButtons');
            const originalHTML = buttons.innerHTML;
            buttons.innerHTML = '<span>Обработка...</span>';
            buttons.style.opacity = '0.6';
            
            // Отправляем AJAX-запрос с таймаутом
            const formData = new FormData();
            formData.append('action', action);
            formData.append('interval', interval);
            formData.append('key', accessKey);
            formData.append('ajax', '1'); // Флаг для AJAX-запроса
            
            // Создаем промис с таймаутом
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error('Таймаут запроса')), 5000);
            });
            
            Promise.race([
                fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                }),
                timeoutPromise
            ])
            .then(response => {
                if (!response || !response.ok) {
                    throw new Error('Ошибка ответа сервера');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Показываем сообщение
                    showMessage(data.message, data.messageType || 'success');
                    
                    // Обновляем интерфейс
                    if (action === 'start' || action === 'restart') {
                        updateUI(true);
                        // Проверяем статус через 2 секунды через AJAX вместо перезагрузки
                        setTimeout(() => {
                            checkStatus();
                        }, 2000);
                    } else if (action === 'stop') {
                        updateUI(false);
                        // Проверяем статус через 1 секунду
                        setTimeout(() => {
                            checkStatus();
                        }, 1000);
                    }
                } else {
                    showMessage(data.message || 'Ошибка выполнения действия', 'error');
                    buttons.innerHTML = originalHTML;
                    buttons.style.opacity = '1';
                }
            })
            .catch(error => {
                console.error('Ошибка:', error);
                // Если таймаут или ошибка, все равно обновляем интерфейс для start/restart
                if (action === 'start' || action === 'restart') {
                    showMessage('Запрос отправлен, проверяем статус...', 'success');
                    updateUI(true);
                    setTimeout(() => {
                        checkStatus();
                    }, 2000);
                } else {
                    showMessage('Ошибка соединения с сервером', 'error');
                    buttons.innerHTML = originalHTML;
                    buttons.style.opacity = '1';
                }
            });
        }
        
        function updateUI(running) {
            const buttons = document.getElementById('actionButtons');
            if (running) {
                buttons.innerHTML = '<button type="button" onclick="performAction(\'restart\')" class="btn">🔄 Перезапустить</button> ' +
                                   '<button type="button" onclick="performAction(\'stop\')" class="btn btn-danger">⏹️ Остановить</button>';
            } else {
                buttons.innerHTML = '<button type="button" onclick="performAction(\'start\')" class="btn btn-success">▶️ Запустить</button>';
            }
            buttons.style.opacity = '1';
            
            // Обновляем статус
            const statusCard = document.querySelector('.status-card');
            if (statusCard) {
                if (running) {
                    statusCard.className = 'status-card running';
                    statusCard.querySelector('h2').textContent = '🟢 Запущен';
                } else {
                    statusCard.className = 'status-card stopped';
                    statusCard.querySelector('h2').textContent = '🔴 Остановлен';
                }
            }
        }
        
        function showMessage(text, type) {
            // Удаляем старое сообщение, если есть
            const oldMessage = document.querySelector('.message');
            if (oldMessage) {
                oldMessage.remove();
            }
            
            // Создаем новое сообщение
            const message = document.createElement('div');
            message.className = 'message' + (type === 'error' ? ' error' : '');
            message.textContent = text;
            
            // Вставляем после заголовка
            const container = document.querySelector('.container');
            const h1 = container.querySelector('h1');
            h1.insertAdjacentElement('afterend', message);
            
            // Автоматически скрываем через 5 секунд
            setTimeout(() => {
                message.remove();
            }, 5000);
        }
        
        function checkStatus() {
            fetch(window.location.href + '?status_check=1&key=' + encodeURIComponent(accessKey))
                .then(response => {
                    if (!response.ok) {
                        throw new Error('HTTP error ' + response.status);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.error) {
                        console.error('Ошибка проверки статуса:', data.error);
                        return;
                    }
                    
                    const currentStatusCard = document.querySelector('.status-card');
                    const currentButtons = document.querySelector('#actionButtons');
                    
                    if (currentStatusCard) {
                        // Обновляем статус
                        currentStatusCard.className = 'status-card ' + data.statusClass;
                        const h2 = currentStatusCard.querySelector('h2');
                        if (h2) {
                            h2.textContent = data.statusText;
                        }
                        
                        // Обновляем информацию о процессе
                        const statusInfo = currentStatusCard.querySelector('.status-info');
                        if (statusInfo) {
                            let infoHtml = '';
                            if (data.isRunning) {
                                if (data.processInfo) {
                                    const pid = String(data.processInfo.pid || 'N/A');
                                    const startTime = String(data.processInfo.start_time || '');
                                    infoHtml += '<p><strong>PID:</strong> ' + pid.replace(/[<>&"']/g, function(m) {
                                        return {'<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;'}[m];
                                    }) + '</p>';
                                    if (startTime) {
                                        infoHtml += '<p><strong>Запущен:</strong> ' + startTime.replace(/[<>&"']/g, function(m) {
                                            return {'<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;'}[m];
                                        }) + '</p>';
                                    }
                                } else {
                                    infoHtml += '<p>Процесс запущен</p>';
                                }
                                infoHtml += '<p style="margin-top: 10px; font-size: 0.9em; color: #666; font-style: italic;">ℹ️ Процесс работает в фоне независимо от браузера. Можно закрыть эту страницу.</p>';
                            } else {
                                infoHtml = '<p>Процесс не запущен</p>';
                            }
                            statusInfo.innerHTML = infoHtml;
                        }
                        
                        // Обновляем кнопки
                        if (currentButtons) {
                            if (data.isRunning) {
                                currentButtons.innerHTML = '<button type="button" onclick="performAction(\'restart\')" class="btn">🔄 Перезапустить</button> ' +
                                                         '<button type="button" onclick="performAction(\'stop\')" class="btn btn-danger">⏹️ Остановить</button>';
                            } else {
                                currentButtons.innerHTML = '<button type="button" onclick="performAction(\'start\')" class="btn btn-success">▶️ Запустить</button>';
                            }
                        }
                        
                        // Если процесс остановлен, останавливаем интервал и перезагружаем страницу
                        if (!data.isRunning && statusCheckInterval !== null) {
                            clearInterval(statusCheckInterval);
                            statusCheckInterval = null;
                            setTimeout(() => {
                                window.location.reload();
                            }, 1000);
                        }
                    }
                })
                .catch(error => {
                    console.error('Ошибка проверки статуса:', error);
                });
        }
        
        // Загружаем лог через AJAX после загрузки страницы (если он не был загружен на сервере)
        function loadLog() {
            const logElement = document.getElementById('logContent');
            if (!logElement) return;
            
            // Если лог уже загружен на сервере, не загружаем повторно
            const currentContent = logElement.textContent.trim();
            if (currentContent && currentContent !== 'Загрузка лога...' && currentContent !== 'Лог пуст') {
                return;
            }
            
            fetch(window.location.href + '?get_log=1&key=' + encodeURIComponent(accessKey))
                .then(response => {
                    if (!response.ok) {
                        throw new Error('HTTP error ' + response.status);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.error) {
                        logElement.textContent = 'Ошибка: ' + data.error;
                    } else if (data.log) {
                        logElement.textContent = data.log;
                    } else {
                        logElement.textContent = 'Лог пуст';
                    }
                })
                .catch(error => {
                    console.error('Ошибка загрузки лога:', error);
                    logElement.textContent = 'Ошибка загрузки лога. Попробуйте обновить страницу.';
                });
        }
        
        // Загружаем лог после загрузки страницы
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', loadLog);
        } else {
            // Страница уже загружена
            setTimeout(loadLog, 100);
        }
        
        <?php if ($isAuthorized && $isRunning): ?>
        // Автообновление статуса каждые 10 секунд через AJAX (без перезагрузки страницы)
        statusCheckInterval = setInterval(function() {
            checkStatus();
        }, 10000);
        <?php endif; ?>
    </script>
</body>
</html>

