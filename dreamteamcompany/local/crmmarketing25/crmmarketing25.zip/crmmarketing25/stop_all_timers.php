<?php
/**
 * Скрипт для остановки всех процессов таймера
 * Использование: вставьте этот код в "Произвольный PHP-скрипт" в админке Bitrix
 */

// Определяем путь к скрипту
$scriptDir = '/local/handlers/crmmarketing25'; // или ваш путь
$scriptPath = $_SERVER['DOCUMENT_ROOT'] . $scriptDir . '/deal_webhook_handler.php';
$pidFile = $_SERVER['DOCUMENT_ROOT'] . $scriptDir . '/deal_timer.pid';
$lockFile = $_SERVER['DOCUMENT_ROOT'] . $scriptDir . '/deal_timer.lock';

echo "<h2>Остановка всех процессов таймера</h2>";
echo "<pre>";

$killed = 0;

if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    // Windows
    echo "Windows обнаружен\n\n";
    
    // Метод 1: Через wmic (самый надежный)
    echo "Метод 1: Остановка через wmic...\n";
    $output = [];
    @exec("wmic process where \"name='php.exe' and commandline like '%deal_webhook_handler.php%' and commandline like '%timer%'\" delete 2>NUL", $output, $result);
    if ($result === 0) {
        echo "✓ Процессы остановлены через wmic\n";
        $killed++;
    } else {
        echo "✗ Не удалось остановить через wmic\n";
    }
    
    // Метод 2: Через tasklist и taskkill
    echo "\nМетод 2: Поиск процессов через tasklist...\n";
    $tasklistOutput = [];
    @exec('tasklist /FI "IMAGENAME eq php.exe" /FO CSV', $tasklistOutput);
    
    foreach ($tasklistOutput as $line) {
        if (strpos($line, 'php.exe') !== false) {
            $parts = str_getcsv($line);
            if (isset($parts[1]) && is_numeric($parts[1])) {
                $pid = (int)$parts[1];
                
                // Проверяем командную строку
                $cmdOutput = [];
                @exec("wmic process where processid=$pid get commandline 2>NUL", $cmdOutput);
                $cmdLine = implode(' ', $cmdOutput);
                
                if (strpos($cmdLine, 'deal_webhook_handler.php') !== false && 
                    (strpos($cmdLine, 'timer') !== false || strpos($cmdLine, 'mode=timer') !== false)) {
                    echo "Найден процесс таймера PID: $pid\n";
                    @exec("taskkill /F /PID $pid 2>NUL", $killOutput, $killResult);
                    if ($killResult === 0) {
                        echo "✓ Процесс $pid остановлен\n";
                        $killed++;
                    }
                }
            }
        }
    }
    
} else {
    // Linux/Unix
    echo "Linux/Unix обнаружен\n\n";
    
    // Метод 1: Через pkill
    echo "Метод 1: Остановка через pkill...\n";
    @exec("pkill -f 'deal_webhook_handler.php.*timer' 2>&1", $pkillOutput, $pkillResult);
    if ($pkillResult === 0 || $pkillResult === 1) { // 1 = процессы не найдены, это нормально
        echo "✓ Команда pkill выполнена\n";
        $killed++;
    }
    
    // Метод 2: Через ps и kill
    echo "\nМетод 2: Поиск процессов через ps...\n";
    $psOutput = [];
    @exec("ps aux | grep 'deal_webhook_handler.php' | grep -v grep", $psOutput);
    
    foreach ($psOutput as $line) {
        if (preg_match('/\s+(\d+)\s+/', $line, $matches)) {
            $pid = (int)$matches[1];
            
            if (strpos($line, 'timer') !== false || strpos($line, 'mode=timer') !== false) {
                echo "Найден процесс таймера PID: $pid\n";
                @exec("kill -9 $pid 2>&1", $killOutput, $killResult);
                if ($killResult === 0) {
                    echo "✓ Процесс $pid остановлен\n";
                    $killed++;
                }
            }
        }
    }
}

// Удаляем файлы блокировки
echo "\nОчистка файлов блокировки...\n";
if (file_exists($pidFile)) {
    @unlink($pidFile);
    echo "✓ PID файл удален: $pidFile\n";
} else {
    echo "- PID файл не найден\n";
}

if (file_exists($lockFile)) {
    @unlink($lockFile);
    echo "✓ Lock файл удален: $lockFile\n";
} else {
    echo "- Lock файл не найден\n";
}

echo "\n" . str_repeat("=", 50) . "\n";
echo "Остановлено процессов: $killed\n";
echo "Готово! Все процессы таймера должны быть остановлены.\n";
echo "\nТеперь используйте только Bitrix агент через deal_agent_manager.php\n";
echo "</pre>";

