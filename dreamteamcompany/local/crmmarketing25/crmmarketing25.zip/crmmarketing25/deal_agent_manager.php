<?php
/**
 * Веб-интерфейс для управления Bitrix агентом выгрузки сделок
 * Доступ: /local/handlers/crmmarketing25/deal_agent_manager.php
 */

// Начинаем перехват вывода САМЫМ ПЕРВЫМ, до инициализации Bitrix
ob_start();

// Инициализация Bitrix
(function (): void {
    $paths = [
        __DIR__ . '/bitrix_init.php',
        __DIR__ . '/../calltouch/calltouch_native/bitrix_init.php',
        __DIR__ . '/../calltouch/bitrix_init.php',
        dirname(__DIR__, 1) . '/calltouch/calltouch_native/bitrix_init.php',
    ];

    foreach ($paths as $path) {
        if (is_file($path)) {
            require_once $path;
            return;
        }
    }

    if (!defined('NO_KEEP_STATISTIC')) {
        define('NO_KEEP_STATISTIC', true);
    }
    if (!defined('NO_AGENT_STATISTIC')) {
        define('NO_AGENT_STATISTIC', true);
    }
    if (!defined('NOT_CHECK_PERMISSIONS')) {
        define('NOT_CHECK_PERMISSIONS', true);
    }

    if (empty($_SERVER['DOCUMENT_ROOT'])) {
        $_SERVER['DOCUMENT_ROOT'] = realpath(__DIR__ . '/../../..');
    }
    if (empty($_SERVER['HTTP_HOST'])) {
        $_SERVER['HTTP_HOST'] = $_SERVER['SERVER_NAME'] ?? 'localhost';
    }

    $prolog = $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';
    if (!is_file($prolog)) {
        die('Не удалось найти bitrix prolog');
    }
    require_once $prolog;
})();

use Bitrix\Main\Loader;

if (!Loader::includeModule('main')) {
    die('Модуль main не доступен');
}

// Ключ для доступа
$accessKey = md5('deal_agent_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
$expectedKey = md5('deal_agent_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
$isAuthorized = isset($_GET['key']) && $_GET['key'] === $expectedKey;

// Получаем текущий статус агента для проверки
$agent = new \CAgent();
$agentName = 'DealExportAgent();';
$dbAgentsCheck = $agent->GetList(
    ['ID' => 'DESC'],
    ['NAME' => $agentName]
);
$currentAgents = [];
while ($arAgent = $dbAgentsCheck->Fetch()) {
    $currentAgents[] = $arAgent;
}

// Обработка действий
$message = '';
$messageType = '';

if ($isAuthorized && isset($_GET['action'])) {
    if ($_GET['action'] === 'register') {
        // Удаляем старый агент
        $agent->Delete(['NAME' => $agentName]);
        
        // Регистрируем новый (следующий запуск - сразу)
        $nextExec = date('d.m.Y H:i:s');
        $agentId = $agent->AddAgent(
            $agentName,
            '',
            'N',
            600, // каждые 10 минут
            '',
            'Y',
            $nextExec, // запустится сразу
            'Y'
        );
        
        if ($agentId) {
            $message = "Агент успешно зарегистрирован (ID: {$agentId})";
            $messageType = 'success';
        } else {
            $message = 'Ошибка регистрации: ' . $agent->LAST_ERROR;
            $messageType = 'error';
        }
    } elseif ($_GET['action'] === 'unregister') {
        // Сначала находим агента по имени
        $dbAgents = $agent->GetList(
            ['ID' => 'DESC'],
            ['NAME' => $agentName]
        );
        
        $deleted = false;
        $deletedCount = 0;
        $deactivatedCount = 0;
        
        while ($arAgent = $dbAgents->Fetch()) {
            $agentId = $arAgent['ID'];
            
            // Пробуем удалить по ID
            if ($agent->Delete($agentId)) {
                $deletedCount++;
                $deleted = true;
            } else {
                // Если удаление не сработало, деактивируем агента
                $updateResult = $agent->Update($agentId, [
                    'ACTIVE' => 'N'
                ]);
                if ($updateResult) {
                    $deactivatedCount++;
                    $deleted = true;
                }
            }
        }
        
        if ($deleted) {
            $msg = [];
            if ($deletedCount > 0) {
                $msg[] = "удалено: {$deletedCount}";
            }
            if ($deactivatedCount > 0) {
                $msg[] = "деактивировано: {$deactivatedCount}";
            }
            $message = "Агент успешно обработан (" . implode(', ', $msg) . ")";
            $messageType = 'success';
        } else {
            $message = 'Агент не найден или уже удален';
            $messageType = 'error';
        }
    } elseif ($_GET['action'] === 'run_now') {
        // Принудительный запуск агента
        $activeAgent = null;
        foreach ($currentAgents as $ag) {
            if ($ag['ACTIVE'] === 'Y') {
                $activeAgent = $ag;
                break;
            }
        }
        
        if ($activeAgent) {
            // Устанавливаем флаги ДО загрузки файлов
            $GLOBALS['DEAL_AGENT_MANAGER_MODE'] = true;
            $GLOBALS['DEAL_AGENT_MODE'] = true;
            
            try {
                // Загружаем функцию агента (весь вывод уже перехвачен)
                require_once __DIR__ . '/deal_agent_handler.php';
                
                // Вызываем функцию агента напрямую
                if (function_exists('DealExportAgent')) {
                    DealExportAgent();
                } else {
                    throw new RuntimeException('Функция DealExportAgent не найдена');
                }
                
                // Обновляем LAST_EXEC и NEXT_EXEC
                // Используем текущее время и добавляем интервал в секундах
                $currentTime = time();
                $agentInterval = (int)($activeAgent['AGENT_INTERVAL'] ?? 600); // 600 секунд = 10 минут
                
                $lastExec = date('d.m.Y H:i:s', $currentTime);
                $nextExec = date('d.m.Y H:i:s', $currentTime + $agentInterval);
                
                // Обновляем оба поля одновременно
                $agent->Update($activeAgent['ID'], [
                    'LAST_EXEC' => $lastExec,
                    'NEXT_EXEC' => $nextExec
                ]);
                
                // Очищаем весь буфер вывода
                ob_clean();
                
                // Сохраняем сообщение в сессию и делаем редирект
                $_SESSION['deal_timer_message'] = 'Агент успешно запущен. Проверьте лог для деталей.';
                $_SESSION['deal_timer_message_type'] = 'success';
                
                $key = $_GET['key'] ?? '';
                $url = $_SERVER['PHP_SELF'] . ($key ? '?key=' . urlencode($key) : '');
                header('Location: ' . $url);
                exit;
            } catch (Throwable $e) {
                // Очищаем буфер в случае ошибки
                ob_clean();
                $message = 'Ошибка запуска агента: ' . $e->getMessage();
                $messageType = 'error';
                error_log("DealExportAgent error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
            }
        } else {
            $message = 'Агент не активен или не найден';
            $messageType = 'error';
        }
    }
}

// Очищаем буфер вывода перед выводом HTML (если не был редирект)
ob_end_clean();

// Запускаем сессию для сообщений
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Получаем сообщения из сессии
if (isset($_SESSION['deal_timer_message'])) {
    $message = $_SESSION['deal_timer_message'];
    $messageType = $_SESSION['deal_timer_message_type'] ?? 'success';
    unset($_SESSION['deal_timer_message'], $_SESSION['deal_timer_message_type']);
}

// Получаем статус агента
$agent = new \CAgent();
$dbAgents = $agent->GetList(
    ['ID' => 'DESC'],
    ['NAME' => 'DealExportAgent();']
);

$agents = [];
while ($arAgent = $dbAgents->Fetch()) {
    $agents[] = $arAgent;
}

// Проверяем активность агента (только активные агенты считаются работающими)
$isActive = false;
$agentInfo = null;
if (!empty($agents)) {
    // Ищем первого активного агента
    foreach ($agents as $ag) {
        if ($ag['ACTIVE'] === 'Y') {
            $isActive = true;
            $agentInfo = $ag;
            break;
        }
    }
    // Если активного нет, берем первого для отображения информации
    if (!$agentInfo) {
        $agentInfo = $agents[0];
    }
}

// Читаем лог агента
// Лог агента - используем тот же файл, что и deal_webhook_handler.php
$logFile = __DIR__ . '/deal_to_lead_webhook.log';
$logContent = '';
$logError = '';

if (file_exists($logFile)) {
    $fileSize = @filesize($logFile);
    if ($fileSize === false) {
        $logError = 'Не удалось определить размер файла лога. Проверьте права доступа.';
    } elseif ($fileSize === 0) {
        $logError = 'Файл лога пуст. Агент еще не выполнялся или не писал в лог.';
    } elseif ($fileSize > 0 && $fileSize < 100 * 1024) {
        $handle = @fopen($logFile, 'r');
        if ($handle) {
            $content = '';
            while (!feof($handle) && strlen($content) < 50 * 1024) {
                $content .= fread($handle, 8192);
            }
            fclose($handle);
            $lines = explode("\n", $content);
            $logContent = implode("\n", array_slice($lines, -50));
        } else {
            $logError = 'Не удалось открыть файл лога для чтения. Проверьте права доступа.';
        }
    } elseif ($fileSize > 100 * 1024) {
        // Читаем только последние 50KB
        $handle = @fopen($logFile, 'r');
        if ($handle) {
            fseek($handle, -50 * 1024, SEEK_END);
            fgets($handle); // Пропускаем первую неполную строку
            $content = '';
            while (!feof($handle)) {
                $content .= fread($handle, 8192);
            }
            fclose($handle);
            $lines = explode("\n", $content);
            $logContent = implode("\n", array_slice($lines, -50));
        } else {
            $logError = 'Не удалось открыть файл лога для чтения. Проверьте права доступа.';
        }
    }
} else {
    $logError = 'Файл лога не найден: ' . basename($logFile) . '. Агент еще не выполнялся.';
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление агентом выгрузки сделок</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 { margin-bottom: 20px; color: #333; }
        .status-card {
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 2px solid;
        }
        .status-card.running {
            background: #e8f5e9;
            border-color: #4caf50;
        }
        .status-card.stopped {
            background: #ffebee;
            border-color: #f44336;
        }
        .status-card h2 {
            margin-bottom: 10px;
            font-size: 24px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            background: #2196F3;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover { background: #1976D2; }
        .btn-success { background: #4CAF50; }
        .btn-success:hover { background: #45a049; }
        .btn-danger { background: #f44336; }
        .btn-danger:hover { background: #da190b; }
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        .log-container {
            margin-top: 20px;
            padding: 15px;
            background: #1e1e1e;
            color: #d4d4d4;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            max-height: 400px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .info {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            border-left: 4px solid #2196F3;
        }
        code {
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Управление агентом выгрузки сделок</h1>
        
        <?php if (!$isAuthorized): ?>
            <div class="info">
                <p><strong>Требуется авторизация</strong></p>
                <p>Код доступа: <code><?php echo htmlspecialchars($accessKey); ?></code></p>
                <p>Добавьте <code>?key=<?php echo htmlspecialchars($accessKey); ?></code> к URL</p>
            </div>
        <?php else: ?>
            <?php if ($message): ?>
                <div class="message <?php echo $messageType === 'error' ? 'error' : ''; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <div class="status-card <?php echo $isActive ? 'running' : 'stopped'; ?>">
                <h2><?php echo $isActive ? '🟢 Агент активен' : '🔴 Агент неактивен'; ?></h2>
                <?php if ($agentInfo): ?>
                    <p><strong>ID:</strong> <?php echo htmlspecialchars($agentInfo['ID']); ?></p>
                    <p><strong>Последний запуск:</strong> <?php echo htmlspecialchars($agentInfo['LAST_EXEC'] ?: 'Никогда'); ?></p>
                    <p><strong>Следующий запуск:</strong> <?php echo htmlspecialchars($agentInfo['NEXT_EXEC'] ?: 'Не запланирован'); ?></p>
                    <p><strong>Интервал:</strong> <?php echo htmlspecialchars($agentInfo['AGENT_INTERVAL']); ?> сек (<?php echo round($agentInfo['AGENT_INTERVAL'] / 60, 1); ?> мин)</p>
                <?php else: ?>
                    <p>Агент не зарегистрирован</p>
                <?php endif; ?>
            </div>
            
            <div style="margin: 20px 0;">
                <?php if ($isActive): ?>
                    <a href="?key=<?php echo urlencode($accessKey); ?>&action=run_now" class="btn btn-success" onclick="this.textContent='Запуск...'; return true;">▶️ Запустить сейчас</a>
                    <a href="?key=<?php echo urlencode($accessKey); ?>&action=unregister" class="btn btn-danger" onclick="return confirm('Вы уверены, что хотите удалить агент?');">⏹️ Удалить агент</a>
                <?php else: ?>
                    <a href="?key=<?php echo urlencode($accessKey); ?>&action=register" class="btn btn-success">▶️ Зарегистрировать агент</a>
                <?php endif; ?>
                <a href="?key=<?php echo urlencode($accessKey); ?>" class="btn">🔄 Обновить</a>
            </div>
            
            <div class="info">
                <p><strong>Как это работает:</strong></p>
                <ul style="margin-left: 20px; margin-top: 10px;">
                    <li>Bitrix агент запускается автоматически каждые 10 минут</li>
                    <li>Агент проверяет новые сделки в облачном Bitrix</li>
                    <li>Создает лиды в коробке Bitrix</li>
                    <li>Работает независимо от браузера и веб-сервера</li>
                    <li>Не требует cron или внешних таймеров</li>
                </ul>
            </div>
            
            <div>
                <h3>Лог агента (последние 50 строк)</h3>
                <?php if ($logError): ?>
                    <div style="color: #ff6b6b; padding: 10px; background: #2d1f1f; border-radius: 4px; margin-bottom: 10px;">
                        ⚠️ <?php echo htmlspecialchars($logError); ?>
                    </div>
                <?php endif; ?>
                <div class="log-container">
                    <?php if ($logContent): ?>
                        <?php echo htmlspecialchars($logContent); ?>
                    <?php else: ?>
                        <div style="color: #888; font-style: italic;">
                            Лог пуст. Агент еще не выполнялся или не писал в лог.
                            <br>Попробуйте нажать "Запустить сейчас" для тестового запуска.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        // Автообновление статуса каждые 10 секунд
        let autoRefreshInterval = null;
        
        function refreshStatus() {
            const url = new URL(window.location.href);
            url.searchParams.set('refresh', '1');
            
            fetch(url.toString())
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newStatusCard = doc.querySelector('.status-card');
                    const currentStatusCard = document.querySelector('.status-card');
                    
                    if (newStatusCard && currentStatusCard) {
                        // Обновляем статус
                        currentStatusCard.className = newStatusCard.className;
                        currentStatusCard.innerHTML = newStatusCard.innerHTML;
                    }
                })
                .catch(error => {
                    console.error('Ошибка обновления статуса:', error);
                });
        }
        
        // Запускаем автообновление только если нет параметра action
        // УВЕЛИЧИЛИ интервал до 60 секунд, чтобы не дергать авторизацию так часто
        const urlParams = new URLSearchParams(window.location.search);
        if (!urlParams.has('action')) {
            autoRefreshInterval = setInterval(refreshStatus, 60000); // каждые 60 секунд (было 10)
        }
        
        // Останавливаем автообновление при уходе со страницы
        window.addEventListener('beforeunload', () => {
            if (autoRefreshInterval) {
                clearInterval(autoRefreshInterval);
            }
        });
    </script>
</body>
</html>

