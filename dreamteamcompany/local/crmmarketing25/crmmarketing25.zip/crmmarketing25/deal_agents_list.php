<?php
/**
 * Скрипт для просмотра всех агентов Bitrix
 * Доступ: /local/handlers/crmmarketing25/deal_agents_list.php
 */

// Начинаем буферизацию вывода САМЫМ ПЕРВЫМ
ob_start();

// Добавляем заголовок для обхода редиректа на страницу входа
$_SERVER['HTTP_X_WEB_INTERFACE'] = '1';

// Включаем отображение ошибок для отладки
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Инициализация Bitrix
try {
    (function (): void {
    $paths = [
        __DIR__ . '/bitrix_init.php',
        __DIR__ . '/../calltouch/calltouch_native/bitrix_init.php',
        __DIR__ . '/../calltouch/bitrix_init.php',
        dirname(__DIR__, 1) . '/calltouch/calltouch_native/bitrix_init.php',
    ];

    foreach ($paths as $path) {
        if (is_file($path)) {
            require_once $path;
            return;
        }
    }

    // Фолбэк на прямое подключение ядра
    if (!defined('NO_KEEP_STATISTIC')) {
        define('NO_KEEP_STATISTIC', true);
    }
    if (!defined('NO_AGENT_STATISTIC')) {
        define('NO_AGENT_STATISTIC', true);
    }
    if (!defined('NOT_CHECK_PERMISSIONS')) {
        define('NOT_CHECK_PERMISSIONS', true);
    }
    if (!defined('BX_WITH_ON_AFTER_EPILOG')) {
        define('BX_WITH_ON_AFTER_EPILOG', true);
    }
    if (!defined('BX_NO_ACCELERATOR_RESET')) {
        define('BX_NO_ACCELERATOR_RESET', true);
    }
    if (!defined('BX_CRONTAB')) {
        define('BX_CRONTAB', true);
    }
    if (!defined('BX_SKIP_POST_UNPACK')) {
        define('BX_SKIP_POST_UNPACK', true);
    }
    // Отключаем проверку авторизации
    $_SERVER['REQUEST_URI'] = $_SERVER['REQUEST_URI'] ?? '/local/handlers/crmmarketing25/deal_agents_list.php';
    // Устанавливаем флаг, что это внутренний запрос
    $_SERVER['SCRIPT_NAME'] = $_SERVER['SCRIPT_NAME'] ?? '/local/handlers/crmmarketing25/deal_agents_list.php';

    if (empty($_SERVER['DOCUMENT_ROOT'])) {
        $_SERVER['DOCUMENT_ROOT'] = realpath(__DIR__ . '/../../..');
    }
    if (empty($_SERVER['HTTP_HOST'])) {
        $_SERVER['HTTP_HOST'] = $_SERVER['SERVER_NAME'] ?? 'localhost';
    }

    $prolog = $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';
    if (!is_file($prolog)) {
        die('Не удалось найти bitrix prolog');
    }
    require_once $prolog;
    })();
} catch (Throwable $e) {
    ob_end_clean();
    die('Ошибка инициализации Bitrix: ' . $e->getMessage() . ' в файле ' . $e->getFile() . ' на строке ' . $e->getLine());
}

use Bitrix\Main\Loader;

if (!Loader::includeModule('main')) {
    ob_end_clean();
    die('Модуль main не доступен');
}

// Обходим проверку авторизации
if (!defined('BX_SKIP_POST_UNPACK')) {
    define('BX_SKIP_POST_UNPACK', true);
}

// Ключ для доступа (опциональный, но рекомендуется для безопасности)
$accessKey = md5('deal_agents_list_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
$expectedKey = md5('deal_agents_list_' . date('Y-m-d') . '_' . ($_SERVER['HTTP_HOST'] ?? 'default'));
$isAuthorized = isset($_GET['key']) && $_GET['key'] === $expectedKey;

// Если ключ не передан, все равно показываем список (но можно добавить проверку)
// Для безопасности можно раскомментировать:
// if (!$isAuthorized) {
//     ob_end_clean();
//     die('Доступ запрещен. Используйте ключ: ?key=' . $accessKey);
// }

// Очищаем буфер перед выводом HTML
ob_end_clean();

// Получаем все агенты
$agent = new \CAgent();
$dbAgents = $agent->GetList(
    ['ID' => 'DESC'],
    []
);

$agents = [];
while ($arAgent = $dbAgents->Fetch()) {
    $agents[] = $arAgent;
}

// Сохраняем результат в файл
$exportFile = __DIR__ . '/deal_agents_export.json';
$exportData = [
    'export_date' => date('Y-m-d H:i:s'),
    'total_agents' => count($agents),
    'agents' => array_map(function($a) {
        return [
            'id' => $a['ID'],
            'name' => $a['NAME'],
            'active' => $a['ACTIVE'] === 'Y',
            'last_exec' => $a['LAST_EXEC'],
            'next_exec' => $a['NEXT_EXEC'],
            'interval' => $a['AGENT_INTERVAL'],
            'sort' => $a['SORT'] ?? null,
        ];
    }, $agents)
];

@file_put_contents(
    $exportFile,
    json_encode($exportData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    LOCK_EX
);

// Форматируем дату
function formatAgentDate($date) {
    if (empty($date) || $date === '0000-00-00 00:00:00' || $date === '01.01.1970 00:00:00') {
        return '<span style="color: #999;">Никогда</span>';
    }
    return $date;
}

// Определяем статус агента
function getAgentStatus($agent) {
    if ($agent['ACTIVE'] !== 'Y') {
        return '<span style="color: #f44336;">🔴 Неактивен</span>';
    }
    
    $nextExec = $agent['NEXT_EXEC'];
    if (empty($nextExec) || $nextExec === '0000-00-00 00:00:00' || $nextExec === '01.01.1970 00:00:00') {
        return '<span style="color: #ff9800;">🟡 Ожидает запуска</span>';
    }
    
    // Парсим дату следующего запуска
    $nextExecTime = strtotime($nextExec);
    $now = time();
    
    if ($nextExecTime <= $now) {
        return '<span style="color: #4caf50;">🟢 Готов к запуску</span>';
    } else {
        $diff = $nextExecTime - $now;
        $minutes = round($diff / 60);
        return '<span style="color: #2196f3;">⏳ Через ' . $minutes . ' мин</span>';
    }
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Список всех агентов Bitrix</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            line-height: 1.6;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            margin-bottom: 10px;
            color: #333;
        }
        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .stat-card {
            flex: 1;
            min-width: 200px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 6px;
            border-left: 4px solid #2196F3;
        }
        .stat-card h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
        .stat-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        .stat-card.active { border-left-color: #4CAF50; }
        .stat-card.inactive { border-left-color: #f44336; }
        .stat-card.ready { border-left-color: #ff9800; }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #dee2e6;
            position: sticky;
            top: 0;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .agent-name {
            font-family: 'Courier New', monospace;
            font-size: 13px;
            color: #2196F3;
            word-break: break-all;
        }
        .agent-id {
            font-weight: bold;
            color: #666;
        }
        .filter-controls {
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 6px;
        }
        .filter-controls label {
            margin-right: 15px;
            font-weight: 500;
        }
        .filter-controls select, .filter-controls input {
            padding: 6px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .search-box {
            margin-top: 10px;
        }
        .search-box input {
            width: 100%;
            max-width: 400px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📋 Список всех агентов Bitrix</h1>
        
        <?php if (!$isAuthorized): ?>
            <div style="background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 6px; margin-bottom: 20px;">
                <strong>⚠️ Для безопасности используйте ключ доступа:</strong>
                <br>Добавьте <code>?key=<?php echo htmlspecialchars($accessKey); ?></code> к URL
            </div>
        <?php endif; ?>
        
        <div style="background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 6px; margin-bottom: 20px;">
            <strong>✅ Данные сохранены в файл:</strong>
            <br><code><?php echo htmlspecialchars(basename($exportFile)); ?></code>
            <br><small>Дата экспорта: <?php echo htmlspecialchars($exportData['export_date']); ?></small>
        </div>
        
        <?php
        $totalAgents = count($agents);
        $activeAgents = count(array_filter($agents, fn($a) => $a['ACTIVE'] === 'Y'));
        $inactiveAgents = $totalAgents - $activeAgents;
        $readyAgents = 0;
        foreach ($agents as $a) {
            if ($a['ACTIVE'] === 'Y') {
                $nextExec = $a['NEXT_EXEC'];
                if (!empty($nextExec) && $nextExec !== '0000-00-00 00:00:00' && $nextExec !== '01.01.1970 00:00:00') {
                    $nextExecTime = strtotime($nextExec);
                    if ($nextExecTime <= time()) {
                        $readyAgents++;
                    }
                }
            }
        }
        ?>
        
        <div class="stats">
            <div class="stat-card">
                <h3>Всего агентов</h3>
                <div class="value"><?php echo $totalAgents; ?></div>
            </div>
            <div class="stat-card active">
                <h3>Активных</h3>
                <div class="value"><?php echo $activeAgents; ?></div>
            </div>
            <div class="stat-card inactive">
                <h3>Неактивных</h3>
                <div class="value"><?php echo $inactiveAgents; ?></div>
            </div>
            <div class="stat-card ready">
                <h3>Готовых к запуску</h3>
                <div class="value"><?php echo $readyAgents; ?></div>
            </div>
        </div>
        
        <div class="filter-controls">
            <label>
                Фильтр:
                <select id="filterStatus" onchange="filterTable()">
                    <option value="all">Все агенты</option>
                    <option value="active">Только активные</option>
                    <option value="inactive">Только неактивные</option>
                    <option value="ready">Готовые к запуску</option>
                </select>
            </label>
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="Поиск по имени агента..." onkeyup="filterTable()">
            </div>
        </div>
        
        <table id="agentsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Статус</th>
                    <th>Имя агента</th>
                    <th>Последний запуск</th>
                    <th>Следующий запуск</th>
                    <th>Интервал</th>
                    <th>Сортировка</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($agents as $agent): ?>
                    <tr data-status="<?php echo $agent['ACTIVE'] === 'Y' ? 'active' : 'inactive'; ?>"
                        data-name="<?php echo htmlspecialchars(strtolower($agent['NAME'])); ?>">
                        <td class="agent-id"><?php echo htmlspecialchars($agent['ID']); ?></td>
                        <td><?php echo getAgentStatus($agent); ?></td>
                        <td class="agent-name"><?php echo htmlspecialchars($agent['NAME']); ?></td>
                        <td><?php echo formatAgentDate($agent['LAST_EXEC']); ?></td>
                        <td><?php echo formatAgentDate($agent['NEXT_EXEC']); ?></td>
                        <td>
                            <?php
                            $interval = $agent['AGENT_INTERVAL'];
                            if (empty($interval)) {
                                echo '<span style="color: #999;">—</span>';
                            } else {
                                $seconds = (int)$interval;
                                if ($seconds < 60) {
                                    echo $seconds . ' сек';
                                } elseif ($seconds < 3600) {
                                    echo round($seconds / 60) . ' мин';
                                } else {
                                    echo round($seconds / 3600, 1) . ' ч';
                                }
                            }
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($agent['SORT'] ?? '—'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <?php if (empty($agents)): ?>
            <p style="text-align: center; padding: 40px; color: #999;">
                Агенты не найдены
            </p>
        <?php endif; ?>
    </div>
    
    <script>
        function filterTable() {
            const filter = document.getElementById('filterStatus').value;
            const search = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('#agentsTable tbody tr');
            
            rows.forEach(row => {
                const status = row.getAttribute('data-status');
                const name = row.getAttribute('data-name');
                
                let show = true;
                
                // Фильтр по статусу
                if (filter === 'active' && status !== 'active') show = false;
                if (filter === 'inactive' && status !== 'inactive') show = false;
                if (filter === 'ready') {
                    const statusCell = row.querySelector('td:nth-child(2)');
                    if (!statusCell || !statusCell.textContent.includes('Готов к запуску')) {
                        show = false;
                    }
                }
                
                // Поиск по имени
                if (show && search && !name.includes(search)) {
                    show = false;
                }
                
                row.style.display = show ? '' : 'none';
            });
        }
    </script>
</body>
</html>

