<?php
declare(strict_types=1);

$GLOBALS['dealWebhookHandleEntered'] = false;
if (!defined('DEAL_WEBHOOK_SIMPLE_MODE')) {
    define('DEAL_WEBHOOK_SIMPLE_MODE', true);
}
logRawRequestForDebug(__DIR__ . '/deal_to_lead_webhook.log');

register_shutdown_function(static function (): void {
    if (!empty($GLOBALS['dealWebhookHandleEntered'])) {
        return;
    }

    $error = error_get_last();
    logRawRequestForDebug(__DIR__ . '/deal_to_lead_webhook.log', [
        'timestamp' => date(DATE_ATOM),
        'type' => 'shutdown_before_handle',
        'error' => $error,
        'sapi' => PHP_SAPI,
    ]);
});

require_once __DIR__ . '/bitrix_init.php';

final class DealToLeadWebhookHandler
{
    private const CLOUD_WEBHOOK_BASE = 'https://crmmarketing25.bitrix24.ru/rest/21/dmrorztmyraz6tkz/';
    private const LOG_FILE = __DIR__ . '/deal_to_lead_webhook.log';
    private const LOG_MAX_BYTES = 2 * 1024 * 1024; // 2 МБ
    private const STATE_FILE = __DIR__ . '/deal_export_state.json';
    private const DEAL_LEAD_MAP_FILE = __DIR__ . '/deal_lead_pairs.json';
    private const DEFAULT_START_DATE = '2025-11-17T00:00:00+03:00';

    private array $fieldMap = [];
    private string $rawRequestBody = '';
    private array $state = [];
    private array $dealLeadPairs = [];

    private array $config = [
        'iblock_id' => 54,
        'source_list_id' => 19,
        'city_list_id' => 22,
        'lead_city_field' => 'UF_CRM_1744362815',
        'lead_executor_field' => 'UF_CRM_1745957138',
        'default_status_id' => 'NEW',
        'error_chat_id' => 'chat69697', // ID чата из боевого примера
    ];

    public function handle(): void
    {
        $GLOBALS['dealWebhookHandleEntered'] = true;
        $this->logIncomingRequest();
        $this->logStep(1, 'Получены сырые данные вебхука');
        header('Content-Type: application/json; charset=utf-8');

        try {
            $this->log('REQUEST SUPERGLOBALS: ' . json_encode([
                '_GET' => $_GET,
                '_POST' => $_POST,
                '_REQUEST' => $_REQUEST,
                'raw_body' => $this->rawRequestBody,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

            $dealId = $this->resolveDealId();
            $this->logStep(2, "Выделен ID сделки: {$dealId}");

            if ($this->hasDealLeadPair($dealId)) {
                $existingLeadId = $this->getDealLeadPair($dealId);
                $this->log("STEP 2A: Сделка {$dealId} уже обработана ранее по deal_lead_pairs.json (лид {$existingLeadId})");
                $this->respond([
                    'status' => 'already_processed',
                    'message' => 'Сделка уже обработана (deal_lead_pairs.json)',
                    'lead_id' => $existingLeadId,
                    'deal_id' => $dealId,
                ]);
                return;
            }
            $this->logStep(2, "Сделка {$dealId} отсутствует в deal_lead_pairs.json");

            $this->log("Определен DEAL_ID={$dealId}");
            $this->log("Старт обработки webhook. DEAL_ID={$dealId}");

            // Проверяем, не обработана ли уже эта сделка
            if ($this->isDealAlreadyProcessed($dealId)) {
                $state = $this->loadState();
                $processedInfo = $state['processed'][(string)$dealId] ?? null;
                $existingLeadId = $processedInfo['lead_id'] ?? null;
                
                $this->log("Сделка {$dealId} уже обработана ранее. Lead ID={$existingLeadId}");
                $this->respond([
                    'status' => 'already_processed',
                    'message' => 'Сделка уже обработана',
                    'lead_id' => $existingLeadId,
                    'deal_id' => $dealId
                ]);
                return;
            }

            $deal = $this->fetchDeal($dealId);
            $leadId = $this->processDealToLead($deal);

            $this->log("Лид успешно создан: ID={$leadId}");
            $this->respond(['status' => 'success', 'lead_id' => $leadId, 'deal_id' => $dealId]);
        } catch (Throwable $e) {
            $this->log("Ошибка: {$e->getMessage()}");
            $this->respond(['status' => 'error', 'message' => $e->getMessage()], 500);
        }
    }


    private function resolveDealId(): int
    {
        $sources = [
            $_REQUEST,
            $_POST,
            $_GET,
        ];

        foreach ($sources as $source) {
            $id = $this->extractDealIdFromArray($source);
            if ($id !== null) {
                return $id;
            }
        }

        if ($this->rawRequestBody !== '') {
            $formData = [];
            parse_str($this->rawRequestBody, $formData);
            if (is_array($formData) && !empty($formData)) {
                $id = $this->extractDealIdFromArray($formData);
                if ($id !== null) {
                    return $id;
                }
            }

            $jsonData = json_decode($this->rawRequestBody, true);
            if (is_array($jsonData) && !empty($jsonData)) {
                $id = $this->extractDealIdFromArray($jsonData);
                if ($id !== null) {
                    return $id;
                }
            }
        }

        throw new InvalidArgumentException('deal_id обязателен (ожидались deal_id, id или data[FIELDS][ID])');
    }

    private function extractDealIdFromArray($payload): ?int
    {
        if (!is_array($payload)) {
            return null;
        }

        $paths = [
            ['deal_id'],
            ['id'],
            ['data', 'FIELDS', 'ID'],
            ['data', 'fields', 'ID'],
            ['data', 'FIELDS', 'id'],
            ['data', 'fields', 'id'],
            ['FIELDS', 'ID'],
            ['fields', 'ID'],
            ['FIELDS', 'id'],
            ['fields', 'id'],
        ];

        foreach ($paths as $path) {
            $value = $this->findNestedValue($payload, $path);
            $intValue = (int)$value;
            if ($value !== null && $intValue > 0) {
                return $intValue;
            }
        }

        foreach ($payload as $key => $value) {
            if (is_array($value)) {
                $nested = $this->extractDealIdFromArray($value);
                if ($nested !== null) {
                    return $nested;
                }
            } elseif (is_string($key) && preg_match('/deal[^a-z0-9]*id/i', $key)) {
                $intValue = (int)$value;
                if ($intValue > 0) {
                    return $intValue;
                }
            } elseif (is_string($key) && preg_match('/data.*fields.*id/i', $key)) {
                $intValue = (int)$value;
                if ($intValue > 0) {
                    return $intValue;
                }
            }
        }

        return null;
    }

    private function findNestedValue(array $data, array $path)
    {
        $current = $data;
        foreach ($path as $segment) {
            if (!is_array($current) || !array_key_exists($segment, $current)) {
                return null;
            }
            $current = $current[$segment];
        }

        return $current;
    }

    private function fetchDeal(int $dealId): array
    {
        $this->log("Запрашиваем сделку через облачный webhook");
        $this->logStep(3, "REST crm.deal.get → отправка (DEAL_ID={$dealId})");
        $deal = $this->callCloudRest('crm.deal.get', ['id' => $dealId])['result'] ?? null;
        $this->logStep(4, 'REST crm.deal.get → ответ: ' . json_encode($deal, JSON_UNESCAPED_UNICODE));
        if (empty($deal) || !is_array($deal)) {
            throw new RuntimeException("Сделка {$dealId} не найдена в облачном портале");
        }

        return $deal;
    }

    private function processDealToLead(array $deal): int
    {
        $dealId = (int)($deal['ID'] ?? 0);
        if ($dealId <= 0) {
            throw new RuntimeException('Некорректный ID сделки');
        }

        $dealTitle = trim((string)($deal['TITLE'] ?? ''));
        if ($dealTitle === '') {
            throw new RuntimeException("У сделки {$dealId} отсутствует название");
        }

        $element = $this->findIblockElementByName($dealTitle);
        if ($element === null) {
            $this->sendIblock54NotFoundNotification($dealId, $dealTitle);
            throw new RuntimeException("Элемент инфоблока 54 с названием '{$dealTitle}' не найден");
        }

        $person = $this->extractPersonData($deal);
        if ($person['firstName'] === '' && $person['lastName'] === '' && $person['phone'] === '') {
            $this->log("В сделке {$dealId} отсутствуют ФИО и телефон. Пробуем подтянуть из контакта.");
            $contactData = $this->fetchContactIfNeeded($deal);
            if ($contactData !== null) {
                $person = $this->hydratePersonFromContact($person, $contactData);
            }
        }

        $leadPayload = $this->buildLeadPayload($dealId, $dealTitle, $person, $element);
        $leadId = $this->persistLead($leadPayload, $dealId);
        $this->logStep(7, "Создан лид {$leadId} на текущем портале для сделки {$dealId}");

        $this->markDealProcessed($dealId, $leadId, $deal['DATE_CREATE'] ?? null);
        $this->addDealLeadPair($dealId, $leadId);
        $this->logStep(8, "Сделка {$dealId} связана с лидом {$leadId} в deal_lead_pairs.json");

        return $leadId;
    }


    private function fetchContactIfNeeded(array $deal): ?array
    {
        $contactId = (int)($deal['CONTACT_ID'] ?? 0);
        if ($contactId <= 0) {
            return null;
        }

        $this->log("Получаем контакт {$contactId} из облака");
        $contact = $this->callCloudRest('crm.contact.get', ['id' => $contactId])['result'] ?? null;

        return is_array($contact) ? $contact : null;
    }

    private function hydratePersonFromContact(array $person, array $contact): array
    {
        $person['firstName'] = $person['firstName'] ?: trim((string)($contact['NAME'] ?? ''));
        $person['middleName'] = $person['middleName'] ?: trim((string)($contact['SECOND_NAME'] ?? ''));
        $person['lastName'] = $person['lastName'] ?: trim((string)($contact['LAST_NAME'] ?? ''));

        if ($person['phone'] === '') {
            $phones = $contact['PHONE'] ?? [];
            if (is_array($phones) && isset($phones[0]['VALUE'])) {
                $person['phone'] = trim((string)$phones[0]['VALUE']);
            }
        }

        return $person;
    }

    private function extractPersonData(array $deal): array
    {
        $fieldsMeta = $this->resolveDealFieldCodes();
        $firstNameCode = $fieldsMeta['firstName'] ?? null;
        $middleNameCode = $fieldsMeta['middleName'] ?? null;
        $lastNameCode = $fieldsMeta['lastName'] ?? null;
        $phoneCode = $fieldsMeta['phone'] ?? null;

        $person = [
            'firstName' => $firstNameCode ? trim((string)($deal[$firstNameCode] ?? '')) : '',
            'middleName' => $middleNameCode ? trim((string)($deal[$middleNameCode] ?? '')) : '',
            'lastName' => $lastNameCode ? trim((string)($deal[$lastNameCode] ?? '')) : '',
            'phone' => '',
        ];

        if ($phoneCode && isset($deal[$phoneCode])) {
            $phoneValue = $deal[$phoneCode];
            if (is_array($phoneValue)) {
                $phoneValue = $phoneValue[0] ?? '';
            }
            $person['phone'] = trim((string)$phoneValue);
        }

        if ($person['phone'] === '' && isset($deal['UF_CRM_PHONE'])) {
            $person['phone'] = trim((string)$deal['UF_CRM_PHONE']);
        }

        if ($person['phone'] !== '') {
            $this->logStep(5, "В сделке найден телефон {$person['phone']}");
        } else {
            $this->logStep(5, 'Телефон в сделке не найден');
        }

        return $person;
    }

    private function buildLeadPayload(int $dealId, string $dealTitle, array $person, array $element): array
    {
        $properties = $element['PROPERTIES'];

        $payload = [
            'TITLE' => (string)$element['NAME'],
            'STATUS_ID' => $this->config['default_status_id'],
            'SOURCE_DESCRIPTION' => sprintf('Создано из сделки #%d (%s)', $dealId, $dealTitle),
        ];

        if ($person['firstName'] !== '') {
            $payload['NAME'] = $person['firstName'];
        }
        if ($person['middleName'] !== '') {
            $payload['SECOND_NAME'] = $person['middleName'];
        }
        if ($person['lastName'] !== '') {
            $payload['LAST_NAME'] = $person['lastName'];
        }
        if ($person['phone'] !== '') {
            $payload['FM'] = [
                'PHONE' => [
                    [
                        'VALUE' => $person['phone'],
                        'VALUE_TYPE' => 'WORK',
                    ],
                ],
            ];
        }

        if (!empty($properties['PROPERTY_192'])) {
            $prop192 = $properties['PROPERTY_192'];
            $this->log("PROPERTY_192 найдено: " . json_encode($prop192, JSON_UNESCAPED_UNICODE));
            
            // Для привязок к элементам используем VALUE_NUM, если оно есть (как в примере)
            $sourceElementId = !empty($prop192['VALUE_NUM']) ? $prop192['VALUE_NUM'] : ($prop192['VALUE'] ?? null);
            
            // Если VALUE - массив, берем первый элемент
            if (is_array($sourceElementId)) {
                $sourceElementId = $sourceElementId[0] ?? null;
            }
            
            $this->log("sourceElementId из PROPERTY_192: " . var_export($sourceElementId, true) . " (VALUE_NUM: " . var_export($prop192['VALUE_NUM'] ?? null, true) . ", VALUE: " . var_export($prop192['VALUE'] ?? null, true) . ")");
            
            if ($sourceElementId) {
                $sourceCode = $this->resolveSourceId((int)$sourceElementId);
                if ($sourceCode) {
                    $payload['SOURCE_ID'] = $sourceCode;
                    $this->log("SOURCE_ID установлен: {$sourceCode}");
                } else {
                    $this->log("Не удалось получить SOURCE_ID из элемента списка 19 ID={$sourceElementId}");
                }
            } else {
                $this->log("sourceElementId пустой после обработки PROPERTY_192");
            }
        } else {
            $this->log("PROPERTY_192 не найдено или пусто");
        }

        if (!empty($properties['PROPERTY_191']['VALUE'])) {
            $cityId = (int)$properties['PROPERTY_191']['VALUE'];
            if ($cityId > 0) {
                $payload[$this->config['lead_city_field']] = $cityId;
                $assigned = $this->resolveAssignedById($cityId);
                if ($assigned > 0) {
                    $payload['ASSIGNED_BY_ID'] = $assigned;
                }
            }
        }

        if (!empty($properties['PROPERTY_193']['VALUE'])) {
            $payload[$this->config['lead_executor_field']] = $properties['PROPERTY_193']['VALUE'];
        }

        if (!empty($properties['PROPERTY_194']['VALUE'])) {
            $payload['COMMENTS'] = trim((string)$properties['PROPERTY_194']['VALUE']);
        }

        $observerIds = $this->extractObserverIds($properties['PROPERTY_195'] ?? null);
        if (!empty($observerIds)) {
            $payload['OBSERVER_IDS'] = $observerIds;
        }

        return $payload;
    }

    private function persistLead(array $payload, int $dealId): int
    {
        if (!CModule::IncludeModule('crm')) {
            throw new RuntimeException('Модуль CRM не доступен');
        }

        $observerIds = $payload['OBSERVER_IDS'] ?? [];
        unset($payload['OBSERVER_IDS']);

        // Используем старый API для создания лида (как в createLeadDirect)
        $lead = new \CCrmLead(false);
        $arFields = [];

        // Основные поля
        if (!empty($payload['TITLE'])) {
            $arFields['TITLE'] = $payload['TITLE'];
        }
        if (!empty($payload['NAME'])) {
            $arFields['NAME'] = $payload['NAME'];
        }
        if (!empty($payload['SECOND_NAME'])) {
            $arFields['SECOND_NAME'] = $payload['SECOND_NAME'];
        }
        if (!empty($payload['LAST_NAME'])) {
            $arFields['LAST_NAME'] = $payload['LAST_NAME'];
        }
        if (!empty($payload['STATUS_ID'])) {
            $arFields['STATUS_ID'] = $payload['STATUS_ID'];
        } else {
            $arFields['STATUS_ID'] = $this->config['default_status_id'];
        }
        if (!empty($payload['SOURCE_ID'])) {
            $arFields['SOURCE_ID'] = $payload['SOURCE_ID'];
        }
        if (!empty($payload['SOURCE_DESCRIPTION'])) {
            $arFields['SOURCE_DESCRIPTION'] = $payload['SOURCE_DESCRIPTION'];
        }
        if (!empty($payload['ASSIGNED_BY_ID'])) {
            $arFields['ASSIGNED_BY_ID'] = (int)$payload['ASSIGNED_BY_ID'];
        }
        if (!empty($payload['COMMENTS'])) {
            $arFields['COMMENTS'] = $payload['COMMENTS'];
        }

        // Пользовательские поля
        foreach ($payload as $key => $value) {
            if (strpos($key, 'UF_CRM_') === 0) {
                $arFields[$key] = $value;
            }
        }

        // Телефоны через мультиполя
        if (!empty($payload['FM']) && is_array($payload['FM'])) {
            $arFields['FM'] = $payload['FM'];
        }

        // Создаем лид
        $leadId = $lead->Add($arFields, true, ['REGISTER_SONET_EVENT' => 'Y']);

        if (!$leadId) {
            $error = $lead->LAST_ERROR;
            throw new RuntimeException('Ошибка создания лида: ' . $error);
        }

        $this->log("Лид успешно создан через CCrmLead::Add, ID={$leadId}");

        // Устанавливаем наблюдателей через D7 API (если есть)
        if (!empty($observerIds)) {
            try {
                $item = \Bitrix\Crm\Item\Lead::createInstance($leadId);
                if ($item) {
                    $item->setObservers($observerIds);
                    $result = $item->save();
                    if ($result->isSuccess()) {
                        $this->log("Наблюдатели успешно установлены для лида ID={$leadId}");
                    } else {
                        $errors = $result->getErrorMessages();
                        $this->log("Ошибки при установке наблюдателей: " . implode(', ', $errors));
                    }
                }
            } catch (Throwable $e) {
                $this->log("Ошибка при установке наблюдателей: {$e->getMessage()}");
                // Не прерываем выполнение, лид уже создан
            }
        }

        return (int)$leadId;
    }

    private function resolveSourceId(int $elementId): ?string
    {
        if ($elementId <= 0 || !CModule::IncludeModule('iblock')) {
            return null;
        }

        $dbProps = CIBlockElement::GetProperty(
            $this->config['source_list_id'],
            $elementId,
            [],
            ['CODE' => 'PROPERTY_73']
        );

        while ($prop = $dbProps->Fetch()) {
            if ($prop['CODE'] === 'PROPERTY_73' && !empty($prop['VALUE'])) {
                $source = trim((string)$prop['VALUE']);
                $this->log("Получен SOURCE_ID='{$source}' из списка 19, элемент ID={$elementId}");
                return $source;
            }
        }
        
        $this->log("PROPERTY_73 не найдено в элементе списка 19 ID={$elementId}");

        return null;
    }

    private function resolveAssignedById(int $cityElementId): int
    {
        if ($cityElementId <= 0 || !CModule::IncludeModule('iblock')) {
            return 0;
        }

        $dbProps = CIBlockElement::GetProperty(
            $this->config['city_list_id'],
            $cityElementId,
            [],
            ['CODE' => 'PROPERTY_185']
        );

        while ($prop = $dbProps->Fetch()) {
            $value = (int)($prop['VALUE'] ?? 0);
            if ($value > 0) {
                $this->log("Определен ответственный {$value} для города {$cityElementId}");
                return $value;
            }
        }

        return 0;
    }

    private function extractObserverIds($property): array
    {
        if (empty($property)) {
            return [];
        }

        $rawValues = [];
        if (is_array($property) && isset($property['VALUE'])) {
            $rawValues = is_array($property['VALUE']) ? $property['VALUE'] : [$property['VALUE']];
        } elseif (is_array($property)) {
            $rawValues = $property;
        }

        $observerIds = array_values(array_filter(array_map(static function ($value) {
            $candidate = is_array($value) ? ($value['VALUE'] ?? $value['VALUE_NUM'] ?? null) : $value;
            $candidate = (int)$candidate;
            return $candidate > 0 ? $candidate : null;
        }, $rawValues), static fn($value) => $value !== null));

        if (!empty($observerIds)) {
            $this->log('Найдены наблюдатели: ' . implode(', ', $observerIds));
        }

        return $observerIds;
    }

    private function findIblockElementByName(string $name): ?array
    {
        if ($name === '') {
            return null;
        }

        if (!CModule::IncludeModule('iblock')) {
            throw new RuntimeException('Модуль iblock не доступен');
        }

        $this->log("Ищем элемент в ИБ54 по имени '{$name}'");
        $dbRes = CIBlockElement::GetList(
            ['ID' => 'ASC'],
            [
                'IBLOCK_ID' => $this->config['iblock_id'],
                'ACTIVE' => 'Y',
                '=NAME' => $name,
            ],
            false,
            ['nTopCount' => 1],
            ['ID', 'NAME']
        );

        $element = $dbRes->Fetch();
        if (!$element) {
            return null;
        }

        $properties = [];
        $dbProps = CIBlockElement::GetProperty($this->config['iblock_id'], (int)$element['ID']);
        while ($prop = $dbProps->Fetch()) {
            $code = $prop['CODE'];
            
            // Для свойств типа "Привязка к элементу" используем VALUE_NUM, если оно есть
            // Иначе используем VALUE (как в примере iblock_functions.php)
            $value = !empty($prop['VALUE_NUM']) ? $prop['VALUE_NUM'] : $prop['VALUE'];

            if (!isset($properties[$code])) {
                $properties[$code] = [
                    'CODE' => $code,
                    'NAME' => $prop['NAME'] ?? '',
                    'VALUE' => $value,
                    'VALUE_ENUM' => $prop['VALUE_ENUM'] ?? null,
                    'VALUE_NUM' => $prop['VALUE_NUM'] ?? null,
                ];
            } else {
                // Обработка множественных значений
                if (!is_array($properties[$code]['VALUE'])) {
                    $properties[$code]['VALUE'] = [$properties[$code]['VALUE'], $value];
                } else {
                    $properties[$code]['VALUE'][] = $value;
                }
            }
        }

        $element['PROPERTIES'] = $properties;
        $this->log("Найден элемент ИБ54 ID={$element['ID']}");
        $this->log("Все свойства элемента ИБ54 ID={$element['ID']}: " . json_encode($properties, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        return $element;
    }

    private function resolveDealFieldCodes(): array
    {
        if (!empty($this->fieldMap)) {
            return $this->fieldMap;
        }

        $this->log('Определяем коды пользовательских полей сделки');
        $fields = $this->callCloudRest('crm.deal.fields');
        $meta = $fields['result'] ?? [];
        if (empty($meta)) {
            return [];
        }

        $targets = [
            'firstName' => ['Имя', 'First name', 'First Name'],
            'middleName' => ['Отчество', 'Middle name', 'Middle Name'],
            'lastName' => ['Фамилия', 'Last name', 'Last Name'],
            'phone' => ['Телефон', 'Phone'],
        ];

        foreach ($targets as $key => $labels) {
            $this->fieldMap[$key] = $this->findFieldCodeByLabels($meta, $labels);
        }

        $this->log('Карта полей сделки: ' . json_encode($this->fieldMap, JSON_UNESCAPED_UNICODE));

        return $this->fieldMap;
    }

    private function findFieldCodeByLabels(array $meta, array $labels): ?string
    {
        foreach ($meta as $code => $definition) {
            $candidates = array_filter([
                $definition['listLabel'] ?? null,
                $definition['formLabel'] ?? null,
                $definition['editFormLabel'] ?? null,
                $definition['filterLabel'] ?? null,
                $definition['title'] ?? null,
            ]);

            foreach ($candidates as $candidate) {
                $normalizedCandidate = mb_strtolower(trim((string)$candidate));
                foreach ($labels as $label) {
                    if ($normalizedCandidate === mb_strtolower(trim($label))) {
                        return $code;
                    }
                }
            }
        }

        return null;
    }

    private function callCloudRest(string $method, array $params = []): array
    {
        $url = rtrim(self::CLOUD_WEBHOOK_BASE, '/') . '/' . $method;
        $this->log("Cloud REST {$method}: " . json_encode($params, JSON_UNESCAPED_UNICODE));

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($params),
            CURLOPT_TIMEOUT => 15,
        ]);

        $response = curl_exec($ch);
        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException("Ошибка REST {$method}: {$error}");
        }
        curl_close($ch);

        $decoded = json_decode($response, true);
        if (!is_array($decoded)) {
            throw new RuntimeException("Некорректный ответ REST {$method}");
        }
        if (!empty($decoded['error'])) {
            $message = $decoded['error_description'] ?? $decoded['error'];
            throw new RuntimeException("REST {$method} вернул ошибку: {$message}");
        }

        return $decoded;
    }

    private function log(string $message): void
    {
        $dir = dirname(self::LOG_FILE);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        if (file_exists(self::LOG_FILE) && filesize(self::LOG_FILE) > self::LOG_MAX_BYTES) {
            $tail = file_get_contents(self::LOG_FILE);
            if ($tail !== false) {
                $tail = substr($tail, -1 * (int)(self::LOG_MAX_BYTES * 0.5));
                file_put_contents(self::LOG_FILE, $tail);
            } else {
                file_put_contents(self::LOG_FILE, '');
            }
        }

        $line = sprintf("[%s] %s\n", date('Y-m-d H:i:s'), $message);
        file_put_contents(self::LOG_FILE, $line, FILE_APPEND);
    }

    private function logIncomingRequest(): void
    {
        $this->rawRequestBody = file_get_contents('php://input') ?: '';

        $record = [
            'timestamp' => date(DATE_ATOM),
            'method' => $_SERVER['REQUEST_METHOD'] ?? (PHP_SAPI === 'cli' ? 'CLI' : 'UNKNOWN'),
            'uri' => $_SERVER['REQUEST_URI'] ?? '',
            'query' => $_SERVER['QUERY_STRING'] ?? '',
            'remote_addr' => $_SERVER['REMOTE_ADDR'] ?? '',
            'headers' => $this->collectHeaders(),
            'get' => $_GET,
            'post' => $_POST,
            'body' => $this->rawRequestBody,
        ];

        $this->log('HTTP запрос: ' . json_encode($record, JSON_UNESCAPED_UNICODE));
    }

    private function logStep(int $step, string $message): void
    {
        $this->log(sprintf('STEP %d: %s', $step, $message));
    }

    private function collectHeaders(): array
    {
        if (function_exists('getallheaders')) {
            $headers = getallheaders();
            if (is_array($headers)) {
                return $headers;
            }
        }

        $result = [];
        foreach ($_SERVER as $key => $value) {
            if (strpos($key, 'HTTP_') === 0) {
                $normalized = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))));
                $result[$normalized] = $value;
            }
        }

        return $result;
    }

    private function loadState(): array
    {
        if (!empty($this->state)) {
            return $this->state;
        }

        // Используем блокировку файла для предотвращения гонок
        $lockFile = self::STATE_FILE . '.lock';
        $maxWait = 10; // максимум 10 секунд ожидания
        $waited = 0;
        
        while (file_exists($lockFile) && $waited < $maxWait) {
            usleep(100000); // 0.1 секунды
            $waited += 0.1;
        }
        
        if (is_file(self::STATE_FILE)) {
            $data = json_decode((string)file_get_contents(self::STATE_FILE), true);
            if (is_array($data)) {
                $this->state = $data;
                if (!isset($this->state['processed']) || !is_array($this->state['processed'])) {
                    $this->state['processed'] = [];
                } else {
                    $this->state['processed'] = $this->normalizeProcessedEntries($this->state['processed']);
                }
            }
        }

        if (empty($this->state)) {
            $this->state = [
                'last_date' => self::DEFAULT_START_DATE,
                'processed' => [],
            ];
        }

        return $this->state;
    }

    private function saveState(): void
    {
        if (empty($this->state)) {
            return;
        }

        $dir = dirname(self::STATE_FILE);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        // Используем блокировку файла для атомарной записи
        $lockFile = self::STATE_FILE . '.lock';
        $lockHandle = @fopen($lockFile, 'w');
        if ($lockHandle) {
            @flock($lockHandle, LOCK_EX);
        }

        try {
            // Перезагружаем состояние перед сохранением, чтобы не потерять изменения
            $currentState = [];
            if (is_file(self::STATE_FILE)) {
                $currentData = json_decode((string)file_get_contents(self::STATE_FILE), true);
                if (is_array($currentData)) {
                    $currentState = $currentData;
                }
            }
            
            // Объединяем текущее состояние с новым (приоритет новому)
            $mergedState = array_merge($currentState, $this->state);
            $mergedState['processed'] = $this->mergeProcessedEntries(
                $currentState['processed'] ?? [],
                $this->state['processed'] ?? []
            );
            if (isset($this->state['last_date'])) {
                $mergedState['last_date'] = max(
                    $mergedState['last_date'] ?? self::DEFAULT_START_DATE,
                    $this->state['last_date']
                );
            }
            
            // Сохраняем объединенное состояние
            file_put_contents(
                self::STATE_FILE,
                json_encode($mergedState, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
                LOCK_EX
            );
            
            // Обновляем кэш
            $this->state = $mergedState;
        } finally {
            if ($lockHandle) {
                @flock($lockHandle, LOCK_UN);
                @fclose($lockHandle);
                @unlink($lockFile);
            }
        }
    }

    private function markDealProcessed(int $dealId, int $leadId, ?string $dateCreate = null): void
    {
        $state = $this->loadState();
        $state['processed'][(string)$dealId] = [
            'lead_id' => $leadId,
            'date' => $dateCreate ?? date(DATE_ATOM),
            'deal_id' => $dealId,
        ];

        if (!empty($dateCreate)) {
            $state['last_date'] = max($state['last_date'] ?? self::DEFAULT_START_DATE, $dateCreate);
        }

        $this->state = $state;
        $this->saveState();
    }

    private function isDealAlreadyProcessed(int $dealId): bool
    {
        $state = $this->loadState();
        return isset($state['processed'][(string)$dealId]);
    }

    private function loadDealLeadPairs(): array
    {
        if (!empty($this->dealLeadPairs)) {
            return $this->dealLeadPairs;
        }

        if (is_file(self::DEAL_LEAD_MAP_FILE)) {
            $data = json_decode((string)file_get_contents(self::DEAL_LEAD_MAP_FILE), true);
            if (is_array($data)) {
                $this->dealLeadPairs = $data;
                return $this->dealLeadPairs;
            }
        }

        $this->dealLeadPairs = [];

        return $this->dealLeadPairs;
    }

    private function hasDealLeadPair(int $dealId): bool
    {
        $pairs = $this->loadDealLeadPairs();
        return isset($pairs[(string)$dealId]);
    }

    private function getDealLeadPair(int $dealId): ?int
    {
        $pairs = $this->loadDealLeadPairs();
        return isset($pairs[(string)$dealId]) ? (int)$pairs[(string)$dealId] : null;
    }

    private function addDealLeadPair(int $dealId, int $leadId): void
    {
        $pairs = $this->loadDealLeadPairs();
        $pairs[(string)$dealId] = $leadId;
        $this->dealLeadPairs = $pairs;
        $this->saveDealLeadPairs();
    }

    private function saveDealLeadPairs(): void
    {
        $dir = dirname(self::DEAL_LEAD_MAP_FILE);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        $tmp = self::DEAL_LEAD_MAP_FILE . '.tmp';
        file_put_contents($tmp, json_encode($this->dealLeadPairs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        rename($tmp, self::DEAL_LEAD_MAP_FILE);
    }

    private function normalizeProcessedEntries($entries): array
    {
        if (!is_array($entries)) {
            return [];
        }

        $result = [];
        $isAssoc = array_keys($entries) !== range(0, count($entries) - 1);

        if ($isAssoc) {
            foreach ($entries as $key => $info) {
                $dealId = (int)$key;
                if ($dealId <= 0 && isset($info['deal_id'])) {
                    $dealId = (int)$info['deal_id'];
                }
                if ($dealId <= 0) {
                    continue;
                }
                $result[(string)$dealId] = [
                    'lead_id' => isset($info['lead_id']) ? (int)$info['lead_id'] : null,
                    'date' => $info['date'] ?? date(DATE_ATOM),
                    'deal_id' => $dealId,
                ];
            }

            return $result;
        }

        // Старый формат в виде списка без deal_id — сохранить как есть не сможем
        return [];
    }

    private function mergeProcessedEntries($current, $new): array
    {
        $currentNormalized = $this->normalizeProcessedEntries($current);
        $newNormalized = $this->normalizeProcessedEntries($new);

        return array_merge($currentNormalized, $newNormalized);
    }

    private function respond(array $payload, int $status = 200): void
    {
        http_response_code($status);
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    private function sendChatMessage(string $chatId, string $message): bool
    {
        try {
            if (!CModule::IncludeModule('im')) {
                $this->log("Модуль IM не доступен для отправки уведомления");
                return false;
            }

            $arFields = [
                'DIALOG_ID' => $chatId,
                'MESSAGE' => $message,
                'SYSTEM' => 'Y',
            ];

            $messageId = CIMMessenger::Add($arFields);

            if ($messageId) {
                $this->log("Уведомление успешно отправлено в чат ID: {$chatId}");
                return true;
            } else {
                $errorMsg = 'Неизвестная ошибка';
                if (isset($GLOBALS['APPLICATION']) && is_object($GLOBALS['APPLICATION'])) {
                    $error = $GLOBALS['APPLICATION']->GetException();
                    if ($error && is_object($error)) {
                        $errorMsg = $error->GetString();
                    }
                }
                $this->log("Ошибка отправки уведомления в чат ID: {$chatId}, ошибка: {$errorMsg}");
                return false;
            }
        } catch (Throwable $e) {
            $this->log("Исключение при отправке уведомления в чат: {$e->getMessage()}");
            return false;
        }
    }

    private function sendIblock54NotFoundNotification(int $dealId, string $dealTitle): void
    {
        $chatId = $this->config['error_chat_id'] ?? null;
        if (!$chatId) {
            $this->log("ID чата для уведомлений не настроен (config.error_chat_id), уведомление не отправлено");
            return;
        }

        $iblockLink = 'https://bitrix.dreamteamcompany.ru/workgroups/group/1/lists/54/view/0/?list_section_id=';
        $cloudPortalLink = 'https://crmmarketing25.bitrix24.ru';

        $message = "🚨 Ошибка обработчика Турбо-сайт\n\n";
        $message .= "❌ Не найден элемент в инфоблоке 54\n\n";
        $message .= "📋 Название: {$dealTitle}\n";
        $message .= "🆔 ID сделки: {$dealId}\n";
        $message .= "⏰ Время: " . date('d.m.Y H:i:s') . "\n\n";
        $message .= "ℹ️ Для повторной выгрузки после добавления элемента в список 54:\n";
        $message .= "1. Перейдите в [URL={$cloudPortalLink}]crmmarketing25.bitrix24.ru[/URL]\n";
        $message .= "2. Найдите сделку #{$dealId}\n";
        $message .= "3. Выгрузите её повторно\n\n";
        $message .= "📝 [URL={$iblockLink}]Открыть список 54[/URL]";

        $this->sendChatMessage($chatId, $message);
    }
}

// Выполняем обработку вебхука
(new DealToLeadWebhookHandler())->handle();
function logRawRequestForDebug(string $file, ?array $recordOverride = null): void
{
    try {
        $record = $recordOverride;
        if ($record === null) {
            $record = [
                'timestamp'   => date(DATE_ATOM),
                'method'      => $_SERVER['REQUEST_METHOD'] ?? (PHP_SAPI === 'cli' ? 'CLI' : 'UNKNOWN'),
                'uri'         => $_SERVER['REQUEST_URI'] ?? '',
                'query'       => $_SERVER['QUERY_STRING'] ?? '',
                'remote_addr' => $_SERVER['REMOTE_ADDR'] ?? '',
                'headers'     => (static function (): array {
                    if (function_exists('getallheaders')) {
                        $headers = getallheaders();
                        if (is_array($headers)) {
                            return $headers;
                        }
                    }

                    $fallback = [];
                    foreach ($_SERVER as $key => $value) {
                        if (strpos($key, 'HTTP_') !== 0) {
                            continue;
                        }

                        $normalized = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))));
                        $fallback[$normalized] = $value;
                    }

                    return $fallback;
                })(),
                'get'         => $_GET,
                'post'        => $_POST,
                'body'        => file_get_contents('php://input') ?: '',
            ];
        }

        $dir = dirname($file);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        $line = sprintf(
            "[%s] %s\n",
            date('Y-m-d H:i:s'),
            json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );

        file_put_contents($file, $line, FILE_APPEND);
    } catch (Throwable $e) {
        // Игнорируем ошибки предварительного логирования, чтобы не мешать основной логике
    }
}
